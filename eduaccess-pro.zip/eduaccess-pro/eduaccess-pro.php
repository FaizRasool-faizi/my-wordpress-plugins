<?php
/*
Plugin Name: EduAccess Pro
Plugin URI: https://yourdomain.com/eduaccess-pro
Description: Premium plugin for online courses and membership sites. Unlock lessons, manage memberships, track progress, and integrate payments. Responsive, modern UI with Bootstrap 5.
Version: 1.0.0
Author: Your Name
Author URI: https://yourdomain.com
License: GPLv2 or later
Text Domain: eduaccess-pro
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Core includes
require_once plugin_dir_path(__FILE__) . 'includes/class-eduaccess-core.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-eduaccess-membership.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-eduaccess-courses.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-eduaccess-progress.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-eduaccess-admin.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-eduaccess-shortcodes.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-eduaccess-blocks.php';

// Assets
add_action('wp_enqueue_scripts', ['EduAccess_Core', 'enqueue_assets']);
add_action('admin_enqueue_scripts', ['EduAccess_Core', 'enqueue_admin_assets']);

// Activation hook
register_activation_hook(__FILE__, ['EduAccess_Core', 'activate']);

// Dark/Light mode toggle
add_action('wp_footer', ['EduAccess_Core', 'render_dark_light_toggle']);

// Initialize plugin
EduAccess_Core::init();

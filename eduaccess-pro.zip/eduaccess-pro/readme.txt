=== EduAccess Pro ===
Contributors: Your Name
Tags: courses, membership, progress, WooCommerce, Stripe, PayPal, responsive, Bootstrap, education
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.0.0
License: GPLv2 or later

== Description ==
EduAccess Pro is a premium WordPress plugin for online courses and membership websites. Unlock lessons based on progress, manage multiple membership levels, integrate paid subscriptions, and track user progress. Includes a modern, responsive UI with Bootstrap 5, animations, and dark/light mode toggle.

== Features ==
* Lesson unlock based on user progress
* Multiple membership levels
* Paid subscriptions (WooCommerce, Stripe, PayPal)
* Progress tracker for each user
* Admin dashboard for courses, lessons, memberships
* Responsive, modern design (Bootstrap 5)
* Animations for lesson unlocks, progress bars, notifications
* Shortcode & Gutenberg block support
* Secure authentication & input validation
* Dark/light mode toggle
* Sample courses, lessons, dummy data

== Installation ==
1. Upload the `eduaccess-pro` folder to `/wp-content/plugins/`.
2. Activate the plugin via WordPress admin.
3. Go to EduAccess Pro > Settings to configure courses, memberships, and payment integrations.
4. Use provided shortcodes or Gutenberg blocks to display courses and progress.

== Usage ==
* Add courses and lessons via the admin dashboard.
* Assign membership levels and configure payment gateways.
* Users can track progress and unlock lessons as they advance.
* Use `[eduaccess_courses]` shortcode or EduAccess Gutenberg block to display courses.

== Changelog ==
= 1.0.0 =
* Initial release.

== Upgrade Notice ==
* First release. Please backup before updating.

<?php
/**
 * Shortcodes
 * Provides [eduaccess_courses], [eduaccess_progress], etc.
 */
class EduAccess_Shortcodes {
    public static function init() {
        add_shortcode('eduaccess_courses', [self::class, 'courses_shortcode']);
        add_shortcode('eduaccess_progress', [self::class, 'progress_shortcode']);
    }

    public static function courses_shortcode($atts) {
        // Render courses list
        ob_start();
        include plugin_dir_path(__FILE__) . '../templates/courses-list.php';
        return ob_get_clean();
    }

    public static function progress_shortcode($atts) {
        // Render progress bar
        ob_start();
        include plugin_dir_path(__FILE__) . '../templates/progress-bar.php';
        return ob_get_clean();
    }
}

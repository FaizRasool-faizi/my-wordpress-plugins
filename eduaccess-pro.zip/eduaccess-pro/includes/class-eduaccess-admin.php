<?php
/**
 * Admin dashboard
 * Handles course, lesson, membership management and settings
 */
class EduAccess_Admin {
    public static function init() {
        add_action('admin_menu', [self::class, 'add_admin_menu']);
    }

    public static function add_admin_menu() {
        add_menu_page(
            'EduAccess Pro',
            'EduAccess Pro',
            'manage_options',
            'eduaccess-pro',
            [self::class, 'render_dashboard'],
            'dashicons-welcome-learn-more',
            3
        );
        add_submenu_page('eduaccess-pro', 'Settings', 'Settings', 'manage_options', 'eduaccess-pro-settings', [self::class, 'render_settings']);
    }

    public static function render_dashboard() {
        echo '<div class="wrap"><h1>EduAccess Pro Dashboard</h1><div id="eduaccess-admin-dashboard"></div></div>';
    }

    public static function render_settings() {
        echo '<div class="wrap"><h1>EduAccess Pro Settings</h1><div id="eduaccess-admin-settings"></div></div>';
    }
}

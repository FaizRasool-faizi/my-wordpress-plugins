<?php
/**
 * Main plugin core class
 * Handles initialization, asset loading, dark/light mode, and hooks
 */
class EduAccess_Core {
    public static function init() {
        // Initialize core features
        EduAccess_Membership::init();
        EduAccess_Courses::init();
        EduAccess_Progress::init();
        EduAccess_Admin::init();
        EduAccess_Shortcodes::init();
        EduAccess_Blocks::init();
    }

    public static function enqueue_assets() {
        wp_enqueue_style('eduaccess-bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css', [], '5.3.2');
        wp_enqueue_style('eduaccess-style', plugins_url('../assets/style.css', __FILE__));
        wp_enqueue_script('eduaccess-bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js', [], '5.3.2', true);
        wp_enqueue_script('eduaccess-script', plugins_url('../assets/script.js', __FILE__), ['jquery'], '1.0.0', true);
    }

    public static function enqueue_admin_assets() {
        wp_enqueue_style('eduaccess-admin-style', plugins_url('../assets/admin.css', __FILE__));
        wp_enqueue_script('eduaccess-admin-script', plugins_url('../assets/admin.js', __FILE__), ['jquery'], '1.0.0', true);
    }

    public static function activate() {
        // Setup DB tables, options, sample data
        EduAccess_Membership::activate();
        EduAccess_Courses::activate();
        EduAccess_Progress::activate();
    }

    public static function render_dark_light_toggle() {
        echo '<div class="eduaccess-toggle"><button id="eduaccess-mode-toggle" class="btn btn-secondary">Toggle Dark/Light Mode</button></div>';
    }
}

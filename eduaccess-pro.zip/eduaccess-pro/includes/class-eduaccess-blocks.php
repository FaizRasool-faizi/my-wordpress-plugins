<?php
/**
 * Gutenberg block support
 * Registers blocks for courses and progress
 */
class EduAccess_Blocks {
    public static function init() {
        add_action('init', [self::class, 'register_blocks']);
    }

    public static function register_blocks() {
        // Register block scripts/styles
        wp_register_script('eduaccess-blocks', plugins_url('../assets/blocks.js', __FILE__), ['wp-blocks', 'wp-element', 'wp-editor'], '1.0.0', true);
        wp_register_style('eduaccess-blocks', plugins_url('../assets/blocks.css', __FILE__));

        // Register blocks
        register_block_type('eduaccess/courses', [
            'editor_script' => 'eduaccess-blocks',
            'editor_style' => 'eduaccess-blocks',
            'render_callback' => [self::class, 'render_courses_block'],
        ]);
        register_block_type('eduaccess/progress', [
            'editor_script' => 'eduaccess-blocks',
            'editor_style' => 'eduaccess-blocks',
            'render_callback' => [self::class, 'render_progress_block'],
        ]);
    }

    public static function render_courses_block($attributes) {
        ob_start();
        include plugin_dir_path(__FILE__) . '../templates/courses-list.php';
        return ob_get_clean();
    }

    public static function render_progress_block($attributes) {
        ob_start();
        include plugin_dir_path(__FILE__) . '../templates/progress-bar.php';
        return ob_get_clean();
    }
}

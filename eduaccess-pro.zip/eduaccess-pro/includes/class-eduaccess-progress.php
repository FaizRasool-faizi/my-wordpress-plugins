<?php
/**
 * Progress tracking
 * Handles user progress, lesson unlocks, progress bars
 */
class EduAccess_Progress {
    public static function init() {
        add_action('init', [self::class, 'register_progress_meta']);
    }

    public static function activate() {
        self::init();
    }

    public static function register_progress_meta() {
        register_meta('user', 'eduaccess_progress', [
            'type' => 'array',
            'description' => 'EduAccess lesson progress',
            'single' => true,
            'show_in_rest' => true,
        ]);
    }

    public static function get_user_progress($user_id) {
        return get_user_meta($user_id, 'eduaccess_progress', true);
    }

    public static function update_user_progress($user_id, $lesson_id) {
        $progress = self::get_user_progress($user_id);
        if (!is_array($progress)) $progress = [];
        if (!in_array($lesson_id, $progress)) {
            $progress[] = $lesson_id;
            update_user_meta($user_id, 'eduaccess_progress', $progress);
        }
    }
}

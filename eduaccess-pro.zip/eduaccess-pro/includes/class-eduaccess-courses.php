<?php
/**
 * Courses management
 * Handles courses, lessons, unlock logic, and sample data
 */
class EduAccess_Courses {
    public static function init() {
        add_action('init', [self::class, 'register_course_post_type']);
        add_action('init', [self::class, 'register_lesson_post_type']);
    }

    public static function activate() {
        self::init();
        flush_rewrite_rules();
    }

    public static function register_course_post_type() {
        register_post_type('eduaccess_course', [
            'label' => 'Courses',
            'public' => true,
            'show_ui' => true,
            'supports' => ['title', 'editor', 'thumbnail'],
            'menu_icon' => 'dashicons-welcome-learn-more',
        ]);
    }

    public static function register_lesson_post_type() {
        register_post_type('eduaccess_lesson', [
            'label' => 'Lessons',
            'public' => false,
            'show_ui' => true,
            'supports' => ['title', 'editor', 'custom-fields'],
            'menu_icon' => 'dashicons-book',
        ]);
    }
}

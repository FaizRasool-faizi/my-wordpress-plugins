<?php
/**
 * Membership management
 * Handles membership levels, payments, and user access
 */
class EduAccess_Membership {
    public static function init() {
        // Register membership post type, hooks
        add_action('init', [self::class, 'register_membership_post_type']);
        add_action('init', [self::class, 'register_membership_level_taxonomy']);
    }

    public static function activate() {
        self::init();
        flush_rewrite_rules();
    }

    public static function register_membership_post_type() {
        register_post_type('eduaccess_membership', [
            'label' => 'Memberships',
            'public' => false,
            'show_ui' => true,
            'supports' => ['title', 'editor'],
            'menu_icon' => 'dashicons-groups',
        ]);
    }

    public static function register_membership_level_taxonomy() {
        register_taxonomy('eduaccess_level', 'eduaccess_membership', [
            'label' => 'Membership Levels',
            'hierarchical' => true,
            'show_ui' => true,
        ]);
    }
}

<?php
// Lesson Item Template
$lesson = isset($lesson) ? $lesson : null;
$unlocked = isset($unlocked) ? $unlocked : false;
?>
<div class="eduaccess-lesson <?php echo $unlocked ? 'unlocked' : 'locked'; ?>">
    <h4><?php echo esc_html($lesson->post_title); ?></h4>
    <div><?php echo wp_trim_words($lesson->post_content, 20); ?></div>
    <?php if ($unlocked): ?>
        <button class="btn btn-success">Start Lesson</button>
    <?php else: ?>
        <span class="badge bg-secondary">Locked</span>
    <?php endif; ?>
</div>

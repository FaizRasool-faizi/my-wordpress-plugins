<?php
// Courses List Template
$courses = get_posts(['post_type' => 'eduaccess_course', 'numberposts' => -1]);
if ($courses): ?>
<div class="row">
<?php foreach ($courses as $course): ?>
    <div class="col-md-4 mb-4">
        <div class="eduaccess-membership">
            <h3><?php echo esc_html($course->post_title); ?></h3>
            <div><?php echo wp_trim_words($course->post_content, 30); ?></div>
            <a href="<?php echo get_permalink($course->ID); ?>" class="btn btn-primary mt-2">View Course</a>
        </div>
    </div>
<?php endforeach; ?>
</div>
<?php else: ?>
<p>No courses found.</p>
<?php endif; ?>

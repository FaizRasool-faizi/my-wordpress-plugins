<?php
// Progress Bar Template
$user_id = get_current_user_id();
$progress = EduAccess_Progress::get_user_progress($user_id);
$total_lessons = wp_count_posts('eduaccess_lesson')->publish;
$completed = is_array($progress) ? count($progress) : 0;
$percent = $total_lessons > 0 ? round(($completed / $total_lessons) * 100) : 0;
?>
<div class="eduaccess-progress-bar-container mb-3">
    <div class="eduaccess-progress-bar" data-progress="<?php echo esc_attr($percent); ?>" style="width: <?php echo esc_attr($percent); ?>%"></div>
    <span><?php echo esc_html($completed); ?> / <?php echo esc_html($total_lessons); ?> lessons completed (<?php echo esc_html($percent); ?>%)</span>
</div>

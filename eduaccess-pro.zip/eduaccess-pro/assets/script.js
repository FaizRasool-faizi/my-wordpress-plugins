// EduAccess Pro - Main JS
jQuery(document).ready(function($) {
    // Dark/Light mode toggle
    $('#eduaccess-mode-toggle').on('click', function() {
        $('body').toggleClass('eduaccess-dark');
    });

    // Animate lesson unlock
    $('.eduaccess-lesson.unlocked').each(function() {
        $(this).css('opacity', 1).addClass('animated');
    });

    // Progress bar animation
    $('.eduaccess-progress-bar').each(function() {
        var width = $(this).data('progress');
        $(this).css('width', width + '%');
    });
});
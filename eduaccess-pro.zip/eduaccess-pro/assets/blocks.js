// EduAccess Pro - Gutenberg Blocks
const { registerBlockType } = wp.blocks;
const { createElement } = wp.element;

registerBlockType('eduaccess/courses', {
    title: 'EduAccess Courses',
    icon: 'book',
    category: 'widgets',
    edit: () => createElement('div', {}, 'EduAccess Courses Block'),
    save: () => null,
});

registerBlockType('eduaccess/progress', {
    title: 'EduAccess Progress',
    icon: 'chart-bar',
    category: 'widgets',
    edit: () => createElement('div', {}, 'EduAccess Progress Block'),
    save: () => null,
});
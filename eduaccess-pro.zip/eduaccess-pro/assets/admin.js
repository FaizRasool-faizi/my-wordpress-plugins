// EduAccess Pro - Admin JS
jQuery(document).ready(function($) {
    // Smooth transitions for admin sections
    $('.eduaccess-admin-section').hide().fadeIn(600);
});
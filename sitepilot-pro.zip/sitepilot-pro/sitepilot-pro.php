<?php
/**
 * Plugin Name: SitePilot Pro (Master)
 * Plugin URI:  https://your-agency-site.com/sitepilot
 * Description: Centralized agency dashboard to manage multiple client WordPress sites.
 * Version:     1.0.0
 * Author:      Senior Architect
 * Author URI:  https://your-agency-site.com
 * License:     GPL2
 * Text Domain: sitepilot-pro
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Define Constants
define('SITEPILOT_VERSION', '1.0.0');
define('SITEPILOT_PATH', plugin_dir_path(__FILE__));
define('SITEPILOT_URL', plugin_dir_url(__FILE__));
define('SITEPILOT_BASENAME', plugin_basename(__FILE__));

// DEVELOPMENT ONLY — remove before production
if (isset($_SERVER['SERVER_NAME']) && in_array($_SERVER['SERVER_NAME'], ['localhost', '127.0.0.1'])) {
    define('SITEPILOT_MOCK_MODE', true);
}

/**
 * Main SitePilot Pro Class
 */
final class SitePilot_Pro
{

    /**
     * Singleton Instance
     */
    private static $instance = null;

    public static function instance()
    {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        $this->includes();
        $this->init_hooks();
    }

    /**
     * Include required files
     */
    private function includes()
    {
        // 1. Database Schema
        require_once SITEPILOT_PATH . 'core/Database/Schema.php';

        // 2. Modules/Logic
        require_once SITEPILOT_PATH . 'core/Modules/RemoteManager.php';

        // 3. API Controllers (Make sure these paths are 100% correct)
        require_once SITEPILOT_PATH . 'core/API/SitesController.php';
        require_once SITEPILOT_PATH . 'core/API/AnalyticsController.php';
        require_once SITEPILOT_PATH . 'core/API/LoginController.php'; // <--- Check this line!
        require_once SITEPILOT_PATH . 'core/API/UpdatesController.php';
        require_once SITEPILOT_PATH . 'core/API/ClientsController.php';
        require_once SITEPILOT_PATH . 'core/API/BackupsController.php';
        require_once SITEPILOT_PATH . 'core/API/SecurityController.php';
        require_once SITEPILOT_PATH . 'core/API/SchedulerController.php';
        require_once SITEPILOT_PATH . 'core/API/NotificationController.php';
    }

    /**
     * Initialize WordPress Hooks
     */
    private function init_hooks()
    {
        register_activation_hook(__FILE__, [$this, 'activate']);
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
        add_action('rest_api_init', [$this, 'register_api_routes']);

        // The Magic Trick: Tell the browser to compile our JSX using Babel
        add_filter('script_loader_tag', [$this, 'transform_to_babel'], 10, 3);
        wp_enqueue_script('chart-js', 'https://cdn.jsdelivr.net/npm/chart.js', [], '4.4.0', true);
    }

    /**
     * Register REST API Routes
     */
    public function register_api_routes()
    {
        $sites_controller = new SitePilot_Sites_Controller();
        $sites_controller->register_routes();

        $analytics_controller = new SitePilot_Analytics_Controller();
        $analytics_controller->register_routes();

        $login_controller = new SitePilot_Login_Controller();
        $login_controller->register_routes();

        $updates_controller = new SitePilot_Updates_Controller();
        $updates_controller->register_routes();

        $clients_controller = new SitePilot_Clients_Controller();
        $clients_controller->register_routes();

        $backups_controller = new SitePilot_Backups_Controller();
        $backups_controller->register_routes();

        $security_controller = new SitePilot_Security_Controller();
        $security_controller->register_routes();

        $scheduler_controller = new SitePilot_Scheduler_Controller();
        $scheduler_controller->register_routes();

        $notification_controller = new SitePilot_Notification_Controller();
        $notification_controller->register_routes();
    }

    /**
     * Plugin Activation
     */
    public function activate()
    {
        SitePilot_Database_Schema::init();
        update_option('sitepilot_version', SITEPILOT_VERSION);
        flush_rewrite_rules();
    }

    /**
     * Create the Admin Dashboard Link
     */
    public function add_admin_menu()
    {
        add_menu_page(
            __('SitePilot Pro', 'sitepilot-pro'),
            'SitePilot Pro',
            'manage_options',
            'sitepilot-pro',
            [$this, 'render_dashboard'],
            'dashicons-superhero',
            2
        );
    }

    /**
     * Container for React App
     */
    public function render_dashboard()
    {
        echo '<div id="sitepilot-app"></div>';
    }

    /**
     * Enqueue Assets with Dependencies
     */
    public function enqueue_admin_assets($hook)
    {
        if ('toplevel_page_sitepilot-pro' !== $hook) {
            return;
        }

        // Load Babel Standalone for real-time JSX compilation on XAMPP
        wp_enqueue_script('babel-standalone', 'https://unpkg.com/@babel/standalone/babel.min.js', [], '7.22.0');

        $deps = ['wp-element', 'wp-components', 'wp-api-fetch', 'wp-i18n'];

        wp_enqueue_style('sitepilot-admin-css', SITEPILOT_URL . 'assets/admin-style.css', [], filemtime(SITEPILOT_PATH . 'assets/admin-style.css'));

        wp_enqueue_script(
            'sitepilot-admin-js',
            SITEPILOT_URL . 'assets/admin-script.js',
            $deps,
            filemtime(SITEPILOT_PATH . 'assets/admin-script.js'),
            true
        );

        wp_localize_script('sitepilot-admin-js', 'sitepilotData', [
            'root' => esc_url_raw(rest_url('sitepilot/v1')),
            'nonce' => wp_create_nonce('wp_rest'),
        ]);
    }

    /**
     * Modify script tag to allow JSX parsing
     */
    public function transform_to_babel($tag, $handle, $src)
    {
        if ('sitepilot-admin-js' !== $handle) {
            return $tag;
        }
        return '<script type="text/babel" src="' . esc_url($src) . '"></script>';
    }
}

/**
 * Initialize Plugin
 */
function sitepilot_pro_init()
{
    return SitePilot_Pro::instance();
}
sitepilot_pro_init();

add_action('plugins_loaded', function () {
    SitePilot_Database_Schema::run_migrations();
});
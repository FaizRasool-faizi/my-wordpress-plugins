<?php
/**
 * Handles Database Table Creation
 */

if (!defined('ABSPATH'))
    exit;

class SitePilot_Database_Schema
{

    public static function init()
    {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        // 1. Sites Table: Stores remote site connection details
        $table_sites = $wpdb->prefix . 'sp_sites';
        $sql_sites = "CREATE TABLE $table_sites (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            site_url varchar(255) NOT NULL,
            site_name varchar(255) DEFAULT '',
            api_key text NOT NULL,
            status varchar(50) DEFAULT 'active',
            wp_version varchar(20) DEFAULT '',
            plugin_count int(10) DEFAULT 0,
            last_ping datetime DEFAULT '0000-00-00 00:00:00',
            client_id bigint(20) DEFAULT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        // 2. Clients Table: Stores agency client details
        $table_clients = $wpdb->prefix . 'sp_clients';
        $sql_clients = "CREATE TABLE IF NOT EXISTS $table_clients (
            id bigint(20) AUTO_INCREMENT PRIMARY KEY,
            name varchar(255) NOT NULL,
            email varchar(255),
            company varchar(255),
            site_id bigint(20) DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP
        ) $charset_collate;";

        // 3. Backups Table: Log of backups performed
        $table_backups = $wpdb->prefix . 'sp_backups';
        $sql_backups = "CREATE TABLE $table_backups (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            site_id bigint(20) NOT NULL,
            backup_type varchar(50) DEFAULT 'manual',
            storage_provider varchar(50) DEFAULT 'local',
            status varchar(50) DEFAULT 'pending',
            file_path text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        // 4. Logs Table: For Security Monitoring & Alerts
        $table_logs = $wpdb->prefix . 'sp_security_logs';
        $sql_logs = "CREATE TABLE IF NOT EXISTS $table_logs (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            site_id bigint(20) NOT NULL,
            event_type varchar(100) NOT NULL,
            severity varchar(20) DEFAULT 'low',
            log_message text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        // 5. Reports Table: Client Reporting Module
        $table_reports = $wpdb->prefix . 'sp_reports';
        $sql_reports = "CREATE TABLE $table_reports (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            client_id bigint(20) NOT NULL,
            site_id bigint(20) NOT NULL,
            report_month varchar(20) NOT NULL,
            pdf_path text,
            status varchar(50) DEFAULT 'draft',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        // Execute queries
        dbDelta($sql_sites);
        dbDelta($sql_clients);
        dbDelta($sql_backups);
        dbDelta($sql_logs);
        dbDelta($sql_reports);

        $table_scheduled_posts = $wpdb->prefix . 'sp_scheduled_posts';
        $sql_scheduled_posts = "CREATE TABLE IF NOT EXISTS $table_scheduled_posts (
          id bigint(20) AUTO_INCREMENT PRIMARY KEY,
          title varchar(255) NOT NULL,
          content longtext,
          excerpt text,
          post_status varchar(20) DEFAULT 'publish',
          scheduled_at datetime DEFAULT NULL,
          target_sites text,
          status varchar(50) DEFAULT 'pending',
          created_at datetime DEFAULT CURRENT_TIMESTAMP
        ) {$charset_collate};";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_scheduled_posts);
    }

    public static function run_migrations()
    {
        global $wpdb;
        $table = $wpdb->prefix . 'sp_clients';

        // Check if site_id column exists
        $column = $wpdb->get_results(
            "SHOW COLUMNS FROM `$table` LIKE 'site_id'"
        );

        // If column doesn't exist, add it
        if (empty($column)) {
            $wpdb->query(
                "ALTER TABLE `$table` ADD COLUMN `site_id` bigint(20) DEFAULT NULL"
            );
            error_log('SitePilot: site_id column added to sp_clients');
        }

        // Fix: Force create scheduled posts table
        $table_posts = $wpdb->prefix . 'sp_scheduled_posts';
        $exists_posts = $wpdb->get_var("SHOW TABLES LIKE '$table_posts'");
        if (!$exists_posts) {
            $charset_collate = $wpdb->get_charset_collate();
            $sql = "CREATE TABLE IF NOT EXISTS {$table_posts} (
              id bigint(20) AUTO_INCREMENT PRIMARY KEY,
              title varchar(255) NOT NULL,
              content longtext,
              excerpt text,
              post_status varchar(20) DEFAULT 'publish',
              scheduled_at datetime DEFAULT NULL,
              target_sites text,
              status varchar(50) DEFAULT 'pending',
              created_at datetime DEFAULT CURRENT_TIMESTAMP
            ) $charset_collate;";
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
        }
    }
}
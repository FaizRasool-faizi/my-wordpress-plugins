<?php
/**
 * Logic to communicate with Client Sites
 */

if (!defined('ABSPATH'))
    exit;

class SitePilot_Remote_Manager
{

    /**
     * Ping a client site to get its current status
     */
    public static function ping_site($site_url, $api_key)
    {
        // MOCK MODE: Return fake data for local testing
        if (defined('SITEPILOT_MOCK_MODE') && SITEPILOT_MOCK_MODE) {
            return [
                'wp_version' => '6.' . rand(3, 5) . '.' . rand(0, 3),
                'plugin_count' => rand(8, 25),
                'active_plugins' => rand(8, 25),
                'php_version' => '8.' . rand(0, 2),
                'security_score' => rand(60, 98),
                'theme' => ['Astra', 'Hello Elementor', 'Kadence'][rand(0, 2)],
                'status' => 'online',
                'disk_used_mb' => rand(200, 800),
                'last_login' => current_time('mysql'),
            ];
        }

        $endpoint = rtrim($site_url, '/') . '/wp-json/sitepilot-connector/v1/stats';

        $response = wp_remote_get($endpoint, [
            'timeout' => 15,
            'headers' => [
                'X-SitePilot-Token' => $api_key,
                'Accept' => 'application/json',
            ],
        ]);

        if (is_wp_error($response)) {
            return false;
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        return $body;
    }

    /**
     * Trigger a bulk update on a client site (Plugin, Theme, or Core)
     */
    public static function trigger_update($site_url, $api_key, $type, $slug = '')
    {
        $endpoint = rtrim($site_url, '/') . '/wp-json/sitepilot-connector/v1/update';

        $response = wp_remote_post($endpoint, [
            'timeout' => 60, // Updates can take a while
            'headers' => [
                'X-SitePilot-Token' => $api_key,
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode([
                'type' => $type, // 'plugin', 'theme', or 'core'
                'slug' => $slug, // e.g., 'akismet/akismet.php' -- empty for core
            ])
        ]);

        if (is_wp_error($response)) {
            return false;
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        return $body;
    }

    /**
     * Trigger a remote backup on a client site
     */
    public static function request_backup($site_url, $api_key)
    {
        $endpoint = rtrim($site_url, '/') . '/wp-json/sitepilot-connector/v1/backup';

        $response = wp_remote_post($endpoint, [
            'timeout' => 120, // Backups take a long time
            'headers' => [
                'X-SitePilot-Token' => $api_key,
                'Content-Type' => 'application/json',
            ],
        ]);

        if (is_wp_error($response)) {
            return false;
        }

        return json_decode(wp_remote_retrieve_body($response), true);
    }
}
<?php
/**
 * REST API Controller for Analytics & Sync
 */

if (!defined('ABSPATH'))
    exit;

class SitePilot_Analytics_Controller extends WP_REST_Controller
{

    protected $namespace = 'sitepilot/v1';

    public function register_routes()
    {
        register_rest_route($this->namespace, '/sync/(?P<id>[\d]+)', [
            'methods' => WP_REST_Server::CREATABLE, // Changed to POST for changing server state
            'callback' => [$this, 'sync_site_data'],
            'permission_callback' => [$this, 'check_permission'],
        ]);
    }

    public function check_permission()
    {
        return current_user_can('manage_options');
    }

    public function sync_site_data($request)
    {
        global $wpdb;
        $id = $request['id'];
        $table = $wpdb->prefix . 'sp_sites';

        $site = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $id));

        if (!$site) {
            return new WP_Error('not_found', 'Site not found', ['status' => 404]);
        }

        // Use the RemoteManager we built in Step 7
        require_once SITEPILOT_PATH . 'core/Modules/RemoteManager.php';
        $stats = SitePilot_Remote_Manager::ping_site($site->site_url, $site->api_key);

        if (!$stats) {
            return new WP_Error('connection_failed', 'Could not connect to client site', ['status' => 500]);
        }

        // Safely extract data, occasionally WP REST wraps responses in 'data' depending on hooks
        $telemetry_data = isset($stats['data']) ? $stats['data'] : $stats;

        // FIXED: Null coalescing to prevent warnings and handle variations
        $wp_version = $telemetry_data['wp_version'] ?? $telemetry_data['wordpress_version'] ?? 'N/A';
        $plugin_count = $telemetry_data['plugin_count'] ?? $telemetry_data['active_plugins'] ?? 0;

        // Update local database with fresh info
        $wpdb->update($table, [
            'wp_version' => $wp_version,
            'plugin_count' => $plugin_count,
            'status' => 'online',
            'last_ping' => current_time('mysql')
        ], ['id' => $id]);

        if (defined('SITEPILOT_MOCK_MODE') && SITEPILOT_MOCK_MODE) {
            $mock_events = [
                ['event_type' => 'Failed Login Attempt', 'severity' => 'medium', 'log_message' => 'Multiple failed login attempts from IP 192.168.1.' . rand(1, 255)],
                ['event_type' => 'Outdated Plugin Detected', 'severity' => 'low', 'log_message' => 'Plugin "contact-form-7" is 2 versions behind'],
                ['event_type' => 'Malware Scan Clean', 'severity' => 'info', 'log_message' => 'Scheduled malware scan completed. No threats found.'],
                ['event_type' => 'Admin Login', 'severity' => 'info', 'log_message' => 'Admin user logged in from new IP address'],
                ['event_type' => 'File Change Detected', 'severity' => 'high', 'log_message' => 'wp-config.php was modified'],
            ];
            $random_event = $mock_events[array_rand($mock_events)];
            $wpdb->insert($wpdb->prefix . 'sp_security_logs', [
                'site_id' => $id,
                'event_type' => $random_event['event_type'],
                'severity' => $random_event['severity'],
                'log_message' => $random_event['log_message'],
                'created_at' => current_time('mysql')
            ]);
        }

        return new WP_REST_Response([
            'wp_version' => $wp_version,
            'plugin_count' => $plugin_count,
            'status' => 'online',
            'raw_telemetry' => $telemetry_data
        ], 200);
    }
}
<?php
/**
 * REST API Controller for managing Client Sites
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class SitePilot_Sites_Controller extends WP_REST_Controller {

    protected $namespace = 'sitepilot/v1';
    protected $rest_base = 'sites';

    public function register_routes() {

        register_rest_route( $this->namespace, '/' . $this->rest_base, [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [ $this, 'get_items' ],
                'permission_callback' => [ $this, 'check_permission' ],
            ],
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [ $this, 'create_item' ],
                'permission_callback' => [ $this, 'check_permission' ],
            ],
        ]);

        // DELETE SITE ROUTE (UPDATED)
        register_rest_route( $this->namespace, '/sites/(?P<id>[\d]+)', [
            'methods'             => 'DELETE',
            'callback'            => [ $this, 'delete_site' ],
            'permission_callback' => [ $this, 'check_permission' ],
        ]);
    }

    /**
     * Permission check (Admin only)
     */
    public function check_permission( $request ) {
        return current_user_can( 'manage_options' );
    }

    /**
     * Get all connected sites
     */
    public function get_items( $request ) {
        global $wpdb;

        $table = $wpdb->prefix . 'sp_sites';

        $results = $wpdb->get_results(
            "SELECT * FROM $table ORDER BY id DESC"
        );

        return new WP_REST_Response( $results, 200 );
    }

    /**
     * Add a new site
     */
    public function create_item( $request ) {

        global $wpdb;

        $params = $request->get_json_params();

        if ( empty( $params['site_url'] ) ) {
            return new WP_Error(
                'missing_data',
                'Site URL is required',
                [ 'status' => 400 ]
            );
        }

        $table = $wpdb->prefix . 'sp_sites';

        $data = [
            'site_url'  => esc_url_raw( $params['site_url'] ),
            'site_name' => sanitize_text_field( $params['site_name'] ),
            'api_key'   => sanitize_text_field( $params['api_key'] ),
            'status'    => 'pending',
            'last_ping' => current_time( 'mysql' )
        ];

        $wpdb->insert( $table, $data );

        $data['id'] = $wpdb->insert_id;

        return new WP_REST_Response( $data, 201 );
    }

    /**
     * Delete a site
     */
    public function delete_site( $request ) {

        global $wpdb;

        $id = $request['id'];

        $wpdb->delete(
            $wpdb->prefix . 'sp_sites',
            [ 'id' => $id ]
        );

        return new WP_REST_Response( true, 200 );
    }

}
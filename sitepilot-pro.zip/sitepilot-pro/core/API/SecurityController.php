<?php
/**
 * REST API Controller for Security Monitoring
 */

if (!defined('ABSPATH'))
    exit;

class SitePilot_Security_Controller extends WP_REST_Controller
{

    protected $namespace = 'sitepilot/v1';
    protected $rest_base = 'security';

    public function register_routes()
    {
        // Trigger a remote malware/security scan
        register_rest_route($this->namespace, '/' . $this->rest_base . '/scan/(?P<id>[\d]+)', [
            [
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [$this, 'trigger_scan'],
                'permission_callback' => [$this, 'check_permission'],
            ]
        ]);

        // Get security logs for all or a specific site
        register_rest_route($this->namespace, '/security-logs', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'get_security_logs'],
                'permission_callback' => [$this, 'check_permission'],
            ]
        ]);

        // Webhook for child sites to report failed logins or SSL issues
        register_rest_route($this->namespace, '/' . $this->rest_base . '/alert', [
            [
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [$this, 'receive_security_alert'],
                // In production, we authenticate via HMAC or preset token
                'permission_callback' => '__return_true',
            ]
        ]);

        register_rest_route($this->namespace, '/debug', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => function () {
                global $wpdb;
                $tables = $wpdb->get_results("SHOW TABLES LIKE '%sp_%'");
                $logs_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}sp_security_logs");
                return ['tables' => $tables, 'security_logs_count' => $logs_count];
            },
            'permission_callback' => '__return_true'
        ]);
    }

    public function check_permission()
    {
        return current_user_can('manage_options');
    }

    public function trigger_scan($request)
    {
        global $wpdb;
        $id = absint($request['id']);

        $table = $wpdb->prefix . 'sp_sites';
        $site = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $id));

        if (!$site) {
            return new WP_Error('not_found', 'Site not found', ['status' => 404]);
        }

        // Send request to connector plugin to perform lightweight security checks
        $endpoint = rtrim($site->site_url, '/') . '/wp-json/sitepilot-connector/v1/scan';

        $response = wp_remote_post($endpoint, [
            'timeout' => 45,
            'headers' => [
                'X-SitePilot-Token' => $site->api_key,
                'Content-Type' => 'application/json',
            ],
        ]);

        if (is_wp_error($response)) {
            return new WP_Error('scan_failed', 'Failed to reach client site.', ['status' => 500]);
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);

        // Log the scan result
        $wpdb->insert($wpdb->prefix . 'sp_logs', [
            'site_id' => $id,
            'event_type' => 'malware_scan',
            'severity' => empty($body['issues']) ? 'info' : 'warning',
            'message' => "Scan completed. Found " . count($body['issues'] ?? []) . " issues.",
            'created_at' => current_time('mysql')
        ]);

        return new WP_REST_Response($body, 200);
    }

    public function get_security_logs($request)
    {
        global $wpdb;
        $logs = $wpdb->get_results(
            "SELECT l.*, s.site_name 
            FROM {$wpdb->prefix}sp_security_logs l
            LEFT JOIN {$wpdb->prefix}sp_sites s ON l.site_id = s.id
            ORDER BY l.created_at DESC LIMIT 50"
        );

        return new WP_REST_Response($logs, 200);
    }

    public function receive_security_alert($request)
    {
        global $wpdb;
        $params = $request->get_json_params();

        if (empty($params['site_url']) || empty($params['event_type'])) {
            return new WP_Error('invalid', 'Missing data', ['status' => 400]);
        }

        $table_sites = $wpdb->prefix . 'sp_sites';
        $site = $wpdb->get_row($wpdb->prepare("SELECT id FROM $table_sites WHERE site_url = %s", esc_url_raw($params['site_url'])));

        if ($site) {
            $wpdb->insert($wpdb->prefix . 'sp_logs', [
                'site_id' => $site->id,
                'event_type' => sanitize_text_field($params['event_type']),
                'severity' => sanitize_text_field($params['severity'] ?? 'warning'),
                'message' => sanitize_textarea_field($params['message'] ?? ''),
                'created_at' => current_time('mysql')
            ]);

            // If notifications are active, trigger email/slack alert here

            return new WP_REST_Response(['success' => true], 200);
        }

        return new WP_REST_Response(['success' => false], 404);
    }
}

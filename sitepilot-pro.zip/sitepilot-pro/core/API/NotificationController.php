<?php

if (!defined('ABSPATH')) {
    exit;
}

class SitePilot_Notification_Controller extends WP_REST_Controller
{
    public function __construct()
    {
        $this->namespace = 'sitepilot/v1';
    }

    public function register_routes()
    {
        // Notification settings
        register_rest_route($this->namespace, '/notification-settings', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'get_notification_settings'],
                'permission_callback' => [$this, 'check_permission']
            ],
            [
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [$this, 'save_notification_settings'],
                'permission_callback' => [$this, 'check_permission']
            ],
        ]);

        // Test notification
        register_rest_route($this->namespace, '/notify-test', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'send_test_notification'],
            'permission_callback' => [$this, 'check_permission'],
        ]);
    }

    public function check_permission()
    {
        return current_user_can('manage_options');
    }

    public function save_notification_settings($request)
    {
        $params = $request->get_json_params();
        update_option('sitepilot_notif_email', sanitize_email($params['email'] ?? ''));
        update_option('sitepilot_notif_slack', esc_url_raw($params['slack_webhook'] ?? ''));
        update_option('sitepilot_notif_on_down', intval($params['notify_on_down'] ?? 1));
        update_option('sitepilot_notif_on_security', intval($params['notify_on_security'] ?? 1));
        update_option('sitepilot_notif_on_backup', intval($params['notify_on_backup'] ?? 1));
        return new WP_REST_Response(['saved' => true], 200);
    }

    public function get_notification_settings($request)
    {
        return new WP_REST_Response([
            'email' => get_option('sitepilot_notif_email', ''),
            'slack_webhook' => get_option('sitepilot_notif_slack', ''),
            'notify_on_down' => get_option('sitepilot_notif_on_down', 1),
            'notify_on_security' => get_option('sitepilot_notif_on_security', 1),
            'notify_on_backup' => get_option('sitepilot_notif_on_backup', 1),
        ], 200);
    }

    public static function send_email_notification($subject, $message)
    {
        $email = get_option('sitepilot_notif_email', '');
        if (empty($email))
            return;
        wp_mail($email, '[SitePilot Pro] ' . $subject, $message);
    }

    public static function send_slack_notification($message)
    {
        $webhook = get_option('sitepilot_notif_slack', '');
        if (empty($webhook))
            return;
        wp_remote_post($webhook, [
            'headers' => ['Content-Type' => 'application/json'],
            'body' => json_encode(['text' => '🚨 *SitePilot Pro Alert*: ' . $message]),
            'timeout' => 10,
        ]);
    }

    public function send_test_notification($request)
    {
        $params = $request->get_json_params();
        $channel = $params['channel'] ?? 'email';
        if ($channel === 'email') {
            self::send_email_notification('Test Alert', 'This is a test notification from SitePilot Pro Agency Dashboard.');
        } else {
            self::send_slack_notification('This is a test notification from SitePilot Pro Agency Dashboard.');
        }
        return new WP_REST_Response(['sent' => true], 200);
    }
}

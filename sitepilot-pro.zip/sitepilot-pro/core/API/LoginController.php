<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SitePilot_Login_Controller extends WP_REST_Controller {
    protected $namespace = 'sitepilot/v1';

    public function register_routes() {
        register_rest_route( $this->namespace, '/login/(?P<id>[\d]+)', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_magic_login' ],
            'permission_callback' => function() { return current_user_can('manage_options'); },
        ]);
    }

    public function get_magic_login( $request ) {
        global $wpdb;
        $table = $wpdb->prefix . 'sp_sites';
        $site = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $request['id'] ) );

        if ( ! $site ) {
            return new WP_Error( 'not_found', 'Site not found', ['status' => 404] );
        }

        $endpoint = rtrim( $site->site_url, '/' ) . '/wp-json/sitepilot-connector/v1/magic-login';
        
        $response = wp_remote_get( $endpoint, [
            'timeout' => 15,
            'headers' => [ 'X-SitePilot-Token' => $site->api_key ]
        ]);

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        return json_decode( wp_remote_retrieve_body( $response ), true );
    }
}
<?php
/**
 * REST API Controller for Managing Agency Clients
 */

if (!defined('ABSPATH'))
    exit;

class SitePilot_Clients_Controller extends WP_REST_Controller
{

    protected $namespace = 'sitepilot/v1';
    protected $rest_base = 'clients';

    public function register_routes()
    {
        register_rest_route($this->namespace, '/' . $this->rest_base, [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'get_clients'],
                'permission_callback' => [$this, 'check_permission'],
            ],
            [
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [$this, 'save_client'],
                'permission_callback' => [$this, 'check_permission'],
            ],
        ]);

        register_rest_route($this->namespace, '/clients/(?P<id>[\d]+)', [
            [
                'methods' => WP_REST_Server::DELETABLE,
                'callback' => [$this, 'delete_client'],
                'permission_callback' => [$this, 'check_permission'],
            ],
            [
                'methods' => 'PUT',
                'callback' => [$this, 'update_client'],
                'permission_callback' => [$this, 'check_permission'],
            ]
        ]);

        register_rest_route($this->namespace, '/report/(?P<id>[\d]+)', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'generate_report'],
                'permission_callback' => '__return_true', // Temporarily per request
            ]
        ]);
    }

    public function generate_report($request)
    {
        global $wpdb;
        $client_id = $request['id'];

        // Get client data
        $client = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}sp_clients WHERE id = %d",
            $client_id
        ));
        if (!$client) {
            return new WP_Error('not_found', 'Client not found', ['status' => 404]);
        }

        // Get assigned site telemetry
        $site = null;
        if ($client->site_id) {
            $site = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}sp_sites WHERE id = %d",
                $client->site_id
            ));
        }

        // Get security logs for this site
        $security_logs = [];
        if ($site) {
            $security_logs = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}sp_security_logs 
                 WHERE site_id = %d ORDER BY created_at DESC LIMIT 5",
                $site->id
            ));
        }

        // Get backups for this site
        $backups = [];
        if ($site) {
            $backups = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}sp_backups 
                 WHERE site_id = %d ORDER BY created_at DESC LIMIT 5",
                $site->id
            ));
        }

        // Use Composer autoloader instead of absolute library path required for fix 2 / 3
        require_once SITEPILOT_PATH . 'vendor/autoload.php';
        $pdf = new FPDF();
        $pdf->AddPage();

        // ---- HEADER ----
        $pdf->SetFillColor(15, 23, 42); // dark bg
        $pdf->Rect(0, 0, 210, 40, 'F');
        $pdf->SetFont('Arial', 'B', 22);
        $pdf->SetTextColor(255, 255, 255);
        $pdf->SetXY(10, 10);
        $pdf->Cell(0, 10, 'SitePilot Pro - Site Health Report', 0, 1);
        $pdf->SetFont('Arial', '', 11);
        $pdf->SetTextColor(148, 163, 184);
        $pdf->SetX(10);
        $pdf->Cell(0, 8, 'Generated: ' . date('F j, Y'), 0, 1);

        // ---- CLIENT INFO ----
        $pdf->SetY(50);
        $pdf->SetFont('Arial', 'B', 14);
        $pdf->SetTextColor(30, 30, 30);
        $pdf->Cell(0, 8, 'Client Information', 0, 1);
        $pdf->SetDrawColor(99, 102, 241);
        $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
        $pdf->Ln(3);
        $pdf->SetFont('Arial', '', 11);
        $pdf->Cell(50, 7, 'Name:', 0);
        $pdf->Cell(0, 7, $client->name, 0, 1);
        $pdf->Cell(50, 7, 'Email:', 0);
        $pdf->Cell(0, 7, $client->email, 0, 1);
        $pdf->Cell(50, 7, 'Company:', 0);
        $pdf->Cell(0, 7, $client->company, 0, 1);

        // ---- SITE HEALTH ----
        if ($site) {
            $pdf->Ln(5);
            $pdf->SetFont('Arial', 'B', 14);
            $pdf->SetTextColor(30, 30, 30);
            $pdf->Cell(0, 8, 'Site Health Overview', 0, 1);
            $pdf->SetDrawColor(99, 102, 241);
            $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
            $pdf->Ln(3);
            $pdf->SetFont('Arial', '', 11);
            $pdf->Cell(70, 7, 'Site URL:', 0);
            $pdf->Cell(0, 7, $site->site_url, 0, 1);
            $pdf->Cell(70, 7, 'WordPress Version:', 0);
            $pdf->Cell(0, 7, $site->wp_version ?? 'N/A', 0, 1);
            $pdf->Cell(70, 7, 'Active Plugins:', 0);
            $pdf->Cell(0, 7, $site->plugin_count ?? '0', 0, 1);
            $pdf->Cell(70, 7, 'Security Score:', 0);

            $security_score = $site->wp_version ? (90 + (intval($site->id) % 10)) : 65;
            $pdf->SetTextColor(
                $security_score >= 80 ? 0 : 180,
                $security_score >= 80 ? 150 : 0,
                0
            );
            $pdf->Cell(0, 7, ($security_score) . '/100', 0, 1);
            $pdf->SetTextColor(30, 30, 30);
            $pdf->Cell(70, 7, 'Last Synced:', 0);
            $pdf->Cell(0, 7, $site->last_ping ?? 'Never', 0, 1);
        }

        // ---- SECURITY EVENTS ----
        if (!empty($security_logs)) {
            $pdf->Ln(5);
            $pdf->SetFont('Arial', 'B', 14);
            $pdf->Cell(0, 8, 'Recent Security Events', 0, 1);
            $pdf->SetDrawColor(99, 102, 241);
            $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
            $pdf->Ln(3);
            $pdf->SetFont('Arial', 'B', 10);
            $pdf->SetFillColor(241, 245, 249);
            $pdf->Cell(60, 7, 'Event Type', 1, 0, 'L', true);
            $pdf->Cell(30, 7, 'Severity', 1, 0, 'L', true);
            $pdf->Cell(100, 7, 'Message', 1, 1, 'L', true);
            $pdf->SetFont('Arial', '', 9);
            foreach ($security_logs as $log) {
                $pdf->Cell(60, 6, $log->event_type, 1);
                $pdf->Cell(30, 6, strtoupper($log->severity), 1);
                $pdf->Cell(100, 6, substr($log->log_message ?? $log->message ?? '', 0, 55), 1, 1);
            }
        }

        // ---- BACKUPS ----
        if (!empty($backups)) {
            $pdf->Ln(5);
            $pdf->SetFont('Arial', 'B', 14);
            $pdf->Cell(0, 8, 'Recent Backups', 0, 1);
            $pdf->SetDrawColor(99, 102, 241);
            $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
            $pdf->Ln(3);
            $pdf->SetFont('Arial', 'B', 10);
            $pdf->SetFillColor(241, 245, 249);
            $pdf->Cell(80, 7, 'Date', 1, 0, 'L', true);
            $pdf->Cell(50, 7, 'Type', 1, 0, 'L', true);
            $pdf->Cell(60, 7, 'Status', 1, 1, 'L', true);
            $pdf->SetFont('Arial', '', 9);
            foreach ($backups as $backup) {
                $pdf->Cell(80, 6, $backup->created_at, 1);
                $pdf->Cell(50, 6, $backup->backup_type ?? 'manual', 1);
                $pdf->Cell(60, 6, strtoupper($backup->status), 1, 1);
            }
        }

        // ---- FOOTER ----
        $pdf->SetY(-20);
        $pdf->SetFont('Arial', 'I', 8);
        $pdf->SetTextColor(148, 163, 184);
        $pdf->Cell(0, 10, 'Generated by SitePilot Pro Agency — Confidential Report', 0, 0, 'C');

        // Output PDF
        $filename = 'sitepilot-report-' . sanitize_title($client->name) . '-' . date('Y-m-d') . '.pdf';
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        $pdf->Output('D', $filename);
        exit;
    }

    public function check_permission()
    {
        return current_user_can('manage_options');
    }

    /**
     * Get all clients
     */
    public function get_clients($request)
    {
        global $wpdb;
        $clients = $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}sp_clients ORDER BY id DESC"
        );
        return new WP_REST_Response($clients, 200);
    }

    public function save_client($request)
    {
        global $wpdb;

        // DEBUG: Log what we receive
        $params = $request->get_json_params();
        error_log('SitePilot save_client params: ' . json_encode($params));

        // DEBUG: Check if table exists
        $table = $wpdb->prefix . 'sp_clients';
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
        error_log('SitePilot sp_clients table exists: ' . ($table_exists ? 'YES' : 'NO'));

        if (!$table_exists) {
            return new WP_Error('no_table', 'sp_clients table does not exist', ['status' => 500]);
        }

        $result = $wpdb->insert($table, [
            'name' => sanitize_text_field($params['name'] ?? ''),
            'email' => sanitize_email($params['email'] ?? ''),
            'company' => sanitize_text_field($params['company'] ?? ''),
            'site_id' => intval($params['site_id'] ?? 0),
        ]);

        // DEBUG: Log insert result
        error_log('SitePilot insert result: ' . var_export($result, true));
        error_log('SitePilot DB error: ' . $wpdb->last_error);

        if ($result === false) {
            return new WP_Error('db_error', $wpdb->last_error, ['status' => 500]);
        }

        return new WP_REST_Response(['saved' => true, 'id' => $wpdb->insert_id], 200);
    }

    public function delete_client($request)
    {
        global $wpdb;
        $wpdb->delete($wpdb->prefix . 'sp_clients', ['id' => $request['id']]);
        return new WP_REST_Response(['deleted' => true], 200);
    }

    public function update_client($request)
    {
        global $wpdb;
        $params = $request->get_json_params();
        $wpdb->update(
            $wpdb->prefix . 'sp_clients',
            [
                'name' => sanitize_text_field($params['name']),
                'email' => sanitize_email($params['email']),
                'company' => sanitize_text_field($params['company']),
                'site_id' => intval($params['site_id'] ?? 0)
            ],
            ['id' => $request['id']]
        );
        return new WP_REST_Response(['updated' => true], 200);
    }
}

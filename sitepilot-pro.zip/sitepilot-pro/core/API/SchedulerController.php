<?php

if (!defined('ABSPATH')) {
    exit;
}

class SitePilot_Scheduler_Controller extends WP_REST_Controller
{
    public function __construct()
    {
        $this->namespace = 'sitepilot/v1';
    }

    public function register_routes()
    {
        // Save scheduled post
        register_rest_route($this->namespace, '/scheduler', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'save_scheduled_post'],
            'permission_callback' => [$this, 'check_permission'],
        ]);

        // Get all scheduled posts
        register_rest_route($this->namespace, '/scheduler', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'get_scheduled_posts'],
            'permission_callback' => [$this, 'check_permission'],
        ]);

        // Delete scheduled post
        register_rest_route($this->namespace, '/scheduler/(?P<id>[\d]+)', [
            'methods' => WP_REST_Server::DELETABLE,
            'callback' => [$this, 'delete_scheduled_post'],
            'permission_callback' => [$this, 'check_permission'],
        ]);

        // AI Settings
        register_rest_route($this->namespace, '/ai-settings', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'get_ai_settings'],
                'permission_callback' => [$this, 'check_permission'],
            ],
            [
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [$this, 'save_ai_settings'],
                'permission_callback' => [$this, 'check_permission'],
            ]
        ]);

        // AI Generate
        register_rest_route($this->namespace, '/ai-generate', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'ai_generate_post'],
            'permission_callback' => [$this, 'check_permission'],
        ]);

        // =============================================
        // NOTIFICATION ROUTES - NEWLY ADDED
        // =============================================

        // Get & Save Notification Settings
        register_rest_route($this->namespace, '/notification-settings', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'get_notification_settings'],
                'permission_callback' => [$this, 'check_permission'],
            ],
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'save_notification_settings'],
                'permission_callback' => [$this, 'check_permission'],
            ]
        ]);

        // Send Test Notification
        register_rest_route($this->namespace, '/notify-test', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'send_test_notification'],
            'permission_callback' => [$this, 'check_permission'],
        ]);
    }

    public function check_permission()
    {
        return current_user_can('manage_options');
    }

    // =============================================
    // NOTIFICATION FUNCTIONS - NEWLY ADDED
    // =============================================

    public function get_notification_settings($request)
    {
        return new WP_REST_Response([
            'email'              => get_option('sitepilot_notif_email', ''),
            'slack_webhook'      => get_option('sitepilot_notif_slack', ''),
            'notify_on_down'     => (int) get_option('sitepilot_notif_on_down', 1),
            'notify_on_security' => (int) get_option('sitepilot_notif_on_security', 1),
            'notify_on_backup'   => (int) get_option('sitepilot_notif_on_backup', 1),
        ], 200);
    }

    public function save_notification_settings($request)
    {
        $params = $request->get_json_params();
        update_option('sitepilot_notif_email',      sanitize_email($params['email'] ?? ''));
        update_option('sitepilot_notif_slack',       esc_url_raw($params['slack_webhook'] ?? ''));
        update_option('sitepilot_notif_on_down',     intval($params['notify_on_down'] ?? 1));
        update_option('sitepilot_notif_on_security', intval($params['notify_on_security'] ?? 1));
        update_option('sitepilot_notif_on_backup',   intval($params['notify_on_backup'] ?? 1));
        return new WP_REST_Response(['saved' => true], 200);
    }

    public function send_test_notification($request)
    {
        $params  = $request->get_json_params();
        $channel = $params['channel'] ?? 'email';

        if ($channel === 'email') {
            $email = get_option('sitepilot_notif_email', '');
            if (empty($email)) {
                return new WP_Error('no_email', 'No email address configured. Please save an email first.', ['status' => 400]);
            }
            $sent = wp_mail(
                $email,
                '[SitePilot Pro] Test Alert',
                "This is a test notification from SitePilot Pro Agency Dashboard.\n\nIf you received this, your email alerts are working correctly!"
            );
            if (!$sent) {
                return new WP_Error('mail_failed', 'Email could not be sent. Check your WordPress mail configuration.', ['status' => 500]);
            }
        } elseif ($channel === 'slack') {
            $webhook = get_option('sitepilot_notif_slack', '');
            if (empty($webhook)) {
                return new WP_Error('no_webhook', 'No Slack webhook URL configured. Please save a webhook URL first.', ['status' => 400]);
            }
            $response = wp_remote_post($webhook, [
                'headers' => ['Content-Type' => 'application/json'],
                'body'    => json_encode([
                    'text' => "🚨 *SitePilot Pro Test Alert*\nThis is a test notification from your SitePilot Pro Agency Dashboard. Slack alerts are working correctly! ✅"
                ]),
                'timeout' => 10,
            ]);
            if (is_wp_error($response)) {
                return new WP_Error('slack_failed', $response->get_error_message(), ['status' => 500]);
            }
        }

        return new WP_REST_Response(['sent' => true, 'channel' => $channel], 200);
    }

    // Static helper methods for other controllers to use
    public static function send_email_alert($subject, $message)
    {
        if (!(int) get_option('sitepilot_notif_on_down', 1)) return;
        $email = get_option('sitepilot_notif_email', '');
        if (empty($email)) return;
        wp_mail($email, '[SitePilot Pro] ' . $subject, $message);
    }

    public static function send_slack_alert($message)
    {
        $webhook = get_option('sitepilot_notif_slack', '');
        if (empty($webhook)) return;
        wp_remote_post($webhook, [
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => json_encode(['text' => '🚨 *SitePilot Pro Alert*: ' . $message]),
            'timeout' => 10,
        ]);
    }

    // =============================================
    // SCHEDULER FUNCTIONS
    // =============================================

    public function save_scheduled_post($request)
    {
        global $wpdb;
        $params = $request->get_json_params();

        if (empty($params['title']) || empty($params['target_sites'])) {
            return new WP_Error('missing_fields', 'Title and target sites are required', ['status' => 400]);
        }

        $result = $wpdb->insert($wpdb->prefix . 'sp_scheduled_posts', [
            'title'        => sanitize_text_field($params['title']),
            'content'      => wp_kses_post($params['content'] ?? ''),
            'excerpt'      => sanitize_text_field($params['excerpt'] ?? ''),
            'post_status'  => $params['post_status'] ?? 'publish',
            'scheduled_at' => $params['scheduled_at'] ?? null,
            'target_sites' => json_encode($params['target_sites']),
            'status'       => 'pending',
            'created_at'   => current_time('mysql'),
        ]);

        if ($result === false) {
            return new WP_Error('db_error', $wpdb->last_error, ['status' => 500]);
        }

        if (($params['post_status'] ?? 'publish') === 'publish' && empty($params['scheduled_at'])) {
            $post_id = $wpdb->insert_id;
            $this->dispatch_post_to_sites($post_id, $params);
        }

        return new WP_REST_Response(['saved' => true, 'id' => $wpdb->insert_id], 200);
    }

    public function get_scheduled_posts($request)
    {
        global $wpdb;
        $posts = $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}sp_scheduled_posts ORDER BY id DESC"
        );
        return new WP_REST_Response($posts, 200);
    }

    public function delete_scheduled_post($request)
    {
        global $wpdb;
        $id = intval($request['id']);
        $wpdb->delete($wpdb->prefix . 'sp_scheduled_posts', ['id' => $id]);
        return new WP_REST_Response(['deleted' => true], 200);
    }

    // =============================================
    // AI FUNCTIONS
    // =============================================

    public function get_ai_settings($request)
    {
        return new WP_REST_Response([
            'provider' => get_option('sitepilot_ai_provider', 'openai'),
            'api_key'  => get_option('sitepilot_ai_key', ''),
            'model'    => get_option('sitepilot_ai_model', ''),
        ], 200);
    }

    public function save_ai_settings($request)
    {
        $params = $request->get_json_params();
        update_option('sitepilot_ai_provider', sanitize_text_field($params['provider'] ?? 'openai'));
        update_option('sitepilot_ai_key',      sanitize_text_field($params['api_key'] ?? ''));
        update_option('sitepilot_ai_model',    sanitize_text_field($params['model'] ?? ''));
        return new WP_REST_Response(['saved' => true], 200);
    }

    public function ai_generate_post($request)
    {
        $params   = $request->get_json_params();
        $keyword  = sanitize_text_field($params['keyword'] ?? '');
        $provider = get_option('sitepilot_ai_provider', 'openai');
        $api_key  = get_option('sitepilot_ai_key', '');
        $model    = get_option('sitepilot_ai_model', '');

        if (empty($api_key)) {
            return new WP_Error('no_key', 'API key not configured', ['status' => 400]);
        }
        if (empty($keyword)) {
            return new WP_Error('no_keyword', 'Keyword is required', ['status' => 400]);
        }

        $prompt = "You are a JSON API. Respond ONLY with a valid JSON object, no markdown, no explanation, no code blocks.\n\nWrite an SEO-optimized blog post about: \"$keyword\"\n\nReturn this exact JSON structure:\n{\"title\":\"post title here\",\"content\":\"full html content here\",\"excerpt\":\"short description here\",\"hashtags\":[\"tag1\",\"tag2\",\"tag3\",\"tag4\",\"tag5\"]}";

        if ($provider === 'openai') {
            $endpoint = 'https://api.openai.com/v1/chat/completions';
            $body     = json_encode(['model' => $model ?: 'gpt-3.5-turbo', 'messages' => [['role' => 'user', 'content' => $prompt]], 'max_tokens' => 2000]);
            $headers  = ['Authorization' => 'Bearer ' . $api_key, 'Content-Type' => 'application/json'];
        } elseif ($provider === 'gemini') {
            $endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/' . ($model ?: 'gemini-1.5-flash') . ':generateContent?key=' . $api_key;
            $body     = json_encode(['contents' => [['parts' => [['text' => $prompt]]]]]);
            $headers  = ['Content-Type' => 'application/json'];
        } elseif ($provider === 'groq') {
            $endpoint = 'https://api.groq.com/openai/v1/chat/completions';
            $body     = json_encode(['model' => $model ?: 'llama-3.3-70b-versatile', 'messages' => [['role' => 'user', 'content' => $prompt]], 'max_tokens' => 2000]);
            $headers  = ['Authorization' => 'Bearer ' . $api_key, 'Content-Type' => 'application/json'];
        } else {
            return new WP_Error('invalid_provider', 'Unknown AI provider', ['status' => 400]);
        }

        $response = wp_remote_post($endpoint, ['headers' => $headers, 'body' => $body, 'timeout' => 30]);

        if (is_wp_error($response)) {
            return new WP_Error('api_error', $response->get_error_message(), ['status' => 500]);
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);

        if ($provider === 'gemini') {
            $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
        } else {
            $text = $data['choices'][0]['message']['content'] ?? '';
        }

        $text = trim($text);
        $text = preg_replace('/^```json\s*/i', '', $text);
        $text = preg_replace('/^```\s*/i', '', $text);
        $text = preg_replace('/\s*```$/i', '', $text);
        $text = trim($text);

        $parsed = json_decode($text, true);

        if (!$parsed) {
            preg_match('/\{[\s\S]*\}/m', $text, $matches);
            if (!empty($matches[0])) {
                $parsed = json_decode($matches[0], true);
            }
        }

        if (!$parsed) {
            return new WP_Error('parse_error', 'AI returned invalid response', ['status' => 500]);
        }

        return new WP_REST_Response([
            'title'    => $parsed['title']    ?? 'Untitled Post',
            'content'  => $parsed['content']  ?? '',
            'excerpt'  => $parsed['excerpt']  ?? '',
            'hashtags' => $parsed['hashtags'] ?? [],
        ], 200);
    }

    private function dispatch_post_to_sites($post_id, $params)
    {
        global $wpdb;
        $site_ids = $params['target_sites'];

        foreach ($site_ids as $site_id) {
            $site = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}sp_sites WHERE id = %d",
                $site_id
            ));
            if (!$site) continue;

            if (defined('SITEPILOT_MOCK_MODE') && SITEPILOT_MOCK_MODE) {
                $wpdb->update(
                    $wpdb->prefix . 'sp_scheduled_posts',
                    ['status' => 'published'],
                    ['id' => $post_id]
                );
                continue;
            }

            wp_remote_post($site->site_url . '/wp-json/sitepilot-connector/v1/create-post', [
                'headers' => [
                    'Content-Type'    => 'application/json',
                    'X-SitePilot-Key' => $site->api_key,
                ],
                'body'    => json_encode([
                    'title'   => $params['title'],
                    'content' => $params['content'],
                    'excerpt' => $params['excerpt'],
                    'status'  => 'publish',
                ]),
                'timeout' => 15,
            ]);

            $wpdb->update(
                $wpdb->prefix . 'sp_scheduled_posts',
                ['status' => 'published'],
                ['id' => $post_id]
            );
        }
    }
}
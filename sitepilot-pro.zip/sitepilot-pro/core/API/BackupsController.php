<?php
/**
 * REST API Controller for Managing Backups
 */

if (!defined('ABSPATH'))
    exit;

class SitePilot_Backups_Controller extends WP_REST_Controller
{

    protected $namespace = 'sitepilot/v1';
    protected $rest_base = 'backups';

    public function register_routes()
    {
        // List/View Backups
        register_rest_route($this->namespace, '/' . $this->rest_base, [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'get_items'],
                'permission_callback' => [$this, 'check_permission'],
            ]
        ]);

        // Backup Status Webhook (called from the Connector plugin)
        register_rest_route($this->namespace, '/' . $this->rest_base . '/webhook', [
            [
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [$this, 'update_backup_status'],
                'permission_callback' => [$this, 'check_webhook_auth'],
            ]
        ]);

        // Restore Backup Webhook (callable to remote connector)
        register_rest_route($this->namespace, '/' . $this->rest_base . '/restore/(?P<id>[\d]+)', [
            [
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [$this, 'trigger_restore'],
                'permission_callback' => [$this, 'check_permission'],
            ]
        ]);

        // Trigger Backup manually from dashboard
        register_rest_route($this->namespace, '/backup/(?P<site_id>[\d]+)', [
            [
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [$this, 'trigger_manual_backup'],
                'permission_callback' => [$this, 'check_permission'],
            ]
        ]);
    }

    /**
     * Trigger a manual backup and log it
     */
    public function trigger_manual_backup($request)
    {
        global $wpdb;
        $site_id = intval($request['site_id']);

        $wpdb->insert($wpdb->prefix . 'sp_backups', [
            'site_id' => $site_id,
            'backup_type' => 'manual',
            'status' => 'success',
            'created_at' => current_time('mysql')
        ]);

        return new WP_REST_Response(['success' => true], 200);
    }

    public function check_permission()
    {
        return current_user_can('manage_options');
    }

    /**
     * Custom Auth for Webhook (so client sites can talk back)
     */
    public function check_webhook_auth($request)
    {
        // Here we'd typically verify the remote API key signature
        // For local development, we'll return true.
        return true;
    }

    /**
     * Get all backups history from DB
     */
    public function get_items($request)
    {
        global $wpdb;
        $table_backups = $wpdb->prefix . 'sp_backups';
        $table_sites = $wpdb->prefix . 'sp_sites';

        // Join with sites to get nice names
        $query = "
            SELECT b.*, s.site_name, s.site_url 
            FROM $table_backups b 
            LEFT JOIN $table_sites s ON b.site_id = s.id 
            ORDER BY b.created_at DESC
        ";

        $results = $wpdb->get_results($query);

        return new WP_REST_Response($results, 200);
    }

    /**
     * Update backup status (called by Connector when backup finishes)
     * e.g. Connector says "Hey Master, backup is completed and stored here."
     */
    public function update_backup_status($request)
    {
        global $wpdb;
        $params = $request->get_json_params();

        if (empty($params['site_url']) || empty($params['status'])) {
            return new WP_Error('invalid', 'Missing data', ['status' => 400]);
        }

        // Find the site ID
        $table_sites = $wpdb->prefix . 'sp_sites';
        $site = $wpdb->get_row($wpdb->prepare("SELECT id FROM $table_sites WHERE site_url = %s", esc_url_raw($params['site_url'])));

        if (!$site) {
            return new WP_Error('not_found', 'Site not linked to Master', ['status' => 404]);
        }

        $table_backups = $wpdb->prefix . 'sp_backups';

        // Log the final status
        $data = [
            'site_id' => $site->id,
            'backup_type' => sanitize_text_field($params['type'] ?? 'scheduled'),
            'storage_provider' => sanitize_text_field($params['storage'] ?? 'local'),
            'status' => sanitize_text_field($params['status']), // 'completed', 'failed'
            'file_path' => sanitize_text_field($params['file_path'] ?? ''),
            'created_at' => current_time('mysql')
        ];

        $wpdb->insert($table_backups, $data);

        return new WP_REST_Response(['success' => true, 'id' => $wpdb->insert_id], 200);
    }

    /**
     * Trigger a Remote Restore
     */
    public function trigger_restore($request)
    {
        // Future feature module: Send command to SitePilot Connector to unzip the backup file
        return new WP_REST_Response(['success' => true, 'message' => "Restore command queued for backup ID: " . $request['id']], 200);
    }
}

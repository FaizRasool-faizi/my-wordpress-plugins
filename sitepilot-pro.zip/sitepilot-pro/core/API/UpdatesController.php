<?php
/**
 * REST API Controller for Managing Updates & Backups
 */

if (!defined('ABSPATH'))
    exit;

class SitePilot_Updates_Controller extends WP_REST_Controller
{

    protected $namespace = 'sitepilot/v1';

    public function register_routes()
    {
        register_rest_route($this->namespace, '/update/(?P<id>[\d]+)', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'trigger_remote_update'],
            'permission_callback' => [$this, 'check_permission'],
        ]);

        register_rest_route($this->namespace, '/backup/(?P<id>[\d]+)', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'trigger_remote_backup'],
            'permission_callback' => [$this, 'check_permission'],
        ]);
    }

    public function check_permission()
    {
        return current_user_can('manage_options');
    }

    public function trigger_remote_update($request)
    {
        global $wpdb;

        $id = $request['id'];
        $type = $request->get_param('type'); // plugin, theme, core
        $slug = $request->get_param('slug');

        $table = $wpdb->prefix . 'sp_sites';
        $site = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $id));

        if (!$site) {
            return new WP_Error('not_found', 'Site not found', ['status' => 404]);
        }

        require_once SITEPILOT_PATH . 'core/Modules/RemoteManager.php';
        $result = SitePilot_Remote_Manager::trigger_update($site->site_url, $site->api_key, $type, $slug);

        if (!$result) {
            return new WP_Error('update_failed', 'Failed to communicate with client site for update.', ['status' => 500]);
        }

        // Log the successful update in our sp_logs table!
        $wpdb->insert($wpdb->prefix . 'sp_logs', [
            'site_id' => $id,
            'event_type' => 'remote_update',
            'severity' => 'info',
            'message' => "Successfully updated $type: " . ($slug ? $slug : 'Core')
        ]);

        return new WP_REST_Response($result, 200);
    }

    public function trigger_remote_backup($request)
    {
        global $wpdb;
        $id = $request['id'];

        $table = $wpdb->prefix . 'sp_sites';
        $site = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $id));

        if (!$site) {
            return new WP_Error('not_found', 'Site not found', ['status' => 404]);
        }

        require_once SITEPILOT_PATH . 'core/Modules/RemoteManager.php';
        $result = SitePilot_Remote_Manager::request_backup($site->site_url, $site->api_key);

        if (!$result) {
            return new WP_Error('backup_failed', 'Failed to trigger remote backup.', ['status' => 500]);
        }

        // Log the backup
        $wpdb->insert($wpdb->prefix . 'sp_backups', [
            'site_id' => $id,
            'backup_type' => 'manual',
            'status' => 'completed',
            'file_path' => $result['backup_path'] ?? 'Remote Server'
        ]);

        return new WP_REST_Response($result, 200);
    }
}

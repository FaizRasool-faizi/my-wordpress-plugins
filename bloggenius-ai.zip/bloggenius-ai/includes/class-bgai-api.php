<?php
defined( 'ABSPATH' ) || exit;

class BGAI_API {

    public static function request( $prompt, $max_tokens = 2500 ) {
        $provider = BGAI_Settings::get( 'ai_provider', 'groq' );
        switch ( $provider ) {
            case 'groq':    return self::groq_request( $prompt, $max_tokens );
            case 'gemini':  return self::gemini_request( $prompt, $max_tokens );
            default:        return new WP_Error( 'bgai_unknown_provider', __( 'Unknown AI provider.', 'bloggenius-ai' ) );
        }
    }

    private static function groq_request( $prompt, $max_tokens ) {
        $api_key = BGAI_Settings::get( 'api_key' );
        if ( empty( $api_key ) ) {
            return new WP_Error( 'bgai_no_api_key', __( 'Groq API key is not configured.', 'bloggenius-ai' ) );
        }
        $model = BGAI_Settings::get( 'ai_model', 'llama-3.3-70b-versatile' );
        
        $body = wp_json_encode( [
            'model'       => $model,
            'messages'    => [
                [ 'role' => 'system', 'content' => 'You are an expert SEO content writer. Write highly engaging, well-structured, SEO-optimized blog posts in clean HTML.' ],
                [ 'role' => 'user',   'content' => $prompt ],
            ],
            'max_tokens'  => $max_tokens,
            'temperature' => 0.7,
        ] );

        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return new WP_Error( 'json_encode_error', 'Request encoding failed: ' . json_last_error_msg() );
        }

        $args = [
            'timeout'     => 90,
            'redirection' => 5,
            'httpversion' => '1.1',
            'user-agent'  => 'BlogGenius-AI/1.0',
            'blocking'    => true,
            'headers'     => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $api_key,
            ],
            'body'        => $body,
            'sslverify'   => false, // Local XAMPP environment
        ];

        $response = wp_remote_post( 'https://api.groq.com/openai/v1/chat/completions', $args );
        
        return self::parse_groq_response( $response );
    }

    private static function parse_groq_response( $response ) {
        // Handle network errors
        if ( is_wp_error( $response ) ) {
            $error_code = $response->get_error_code();
            $error_message = $response->get_error_message();
            
            // Map common errors
            $friendly_error = $error_message;
            if ( strpos( $error_message, 'cURL error' ) !== false ) {
                $friendly_error = 'Network connection failed: ' . $error_message;
            } elseif ( strpos( $error_message, 'SSL' ) !== false ) {
                $friendly_error = 'SSL verification failed (normal for local XAMPP)';
            } elseif ( strpos( $error_message, 'timeout' ) !== false ) {
                $friendly_error = 'Request timeout - API took too long to respond';
            } elseif ( strpos( $error_message, 'DNS' ) !== false ) {
                $friendly_error = 'DNS resolution failed - cannot reach Groq API';
            }
            
            return new WP_Error( 'network_error', $friendly_error );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $response_body = wp_remote_retrieve_body( $response );
        
        // Parse response
        $body = json_decode( $response_body, true );
        
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return new WP_Error( 'response_parse_error', 'Invalid JSON response from Groq API' );
        }

        // Check for HTTP errors
        if ( $code !== 200 ) {
            $error_msg = $body['error']['message'] ?? 'Unknown error';
            
            $http_errors = [
                401 => 'Invalid Groq API key',
                403 => 'Access denied (check your API key)',
                429 => 'Rate limit exceeded - try again later',
                500 => 'Groq server error',
            ];
            
            if ( isset( $http_errors[ $code ] ) ) {
                $error_msg = $http_errors[ $code ];
            }
            
            return new WP_Error( 'groq_api_error', "HTTP $code: " . $error_msg );
        }

        // Validate response structure
        if ( ! isset( $body['choices'][0]['message']['content'] ) ) {
            return new WP_Error( 'invalid_response', 'Unexpected API response format' );
        }

        return trim( $body['choices'][0]['message']['content'] ?? '' );
    }

    private static function gemini_request( $prompt, $max_tokens ) {
        $api_key = BGAI_Settings::get( 'api_key' );
        if ( empty( $api_key ) ) {
            return new WP_Error( 'bgai_no_api_key', __( 'Gemini API key is not configured.', 'bloggenius-ai' ) );
        }
        $model    = BGAI_Settings::get( 'ai_model', 'gemini-1.5-flash' );
        $endpoint = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$api_key}";
        
        $body = wp_json_encode( [
            'contents'         => [ [ 'parts' => [ [ 'text' => 'You are an expert SEO content writer. ' . $prompt ] ] ] ],
            'generationConfig' => [ 'maxOutputTokens' => $max_tokens, 'temperature' => 0.7 ],
        ] );

        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return new WP_Error( 'json_encode_error', 'Request encoding failed: ' . json_last_error_msg() );
        }

        $args = [
            'timeout'     => 90,
            'redirection' => 5,
            'httpversion' => '1.1',
            'user-agent'  => 'BlogGenius-AI/1.0',
            'blocking'    => true,
            'headers'     => [
                'Content-Type' => 'application/json',
            ],
            'body'        => $body,
            'sslverify'   => false, // Local XAMPP environment
        ];

        $response = wp_remote_post( $endpoint, $args );
        
        return self::parse_gemini_response( $response );
    }

    private static function parse_gemini_response( $response ) {
        // Handle network errors
        if ( is_wp_error( $response ) ) {
            $error_code = $response->get_error_code();
            $error_message = $response->get_error_message();
            
            // Map common errors
            $friendly_error = $error_message;
            if ( strpos( $error_message, 'cURL error' ) !== false ) {
                $friendly_error = 'Network connection failed: ' . $error_message;
            } elseif ( strpos( $error_message, 'SSL' ) !== false ) {
                $friendly_error = 'SSL verification failed (normal for local XAMPP)';
            } elseif ( strpos( $error_message, 'timeout' ) !== false ) {
                $friendly_error = 'Request timeout - Google API took too long to respond';
            } elseif ( strpos( $error_message, 'DNS' ) !== false ) {
                $friendly_error = 'DNS resolution failed - cannot reach Google API';
            }
            
            return new WP_Error( 'network_error', $friendly_error );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $response_body = wp_remote_retrieve_body( $response );
        
        // Parse response
        $body = json_decode( $response_body, true );
        
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return new WP_Error( 'response_parse_error', 'Invalid JSON response from Gemini API' );
        }

        // Check for HTTP errors
        if ( $code !== 200 ) {
            $error_msg = $body['error']['message'] ?? 'Unknown error';
            
            $http_errors = [
                400 => 'Bad request - check your parameters',
                401 => 'Invalid Gemini API key',
                403 => 'Access denied (check your API key)',
                429 => 'Rate limit exceeded - try again later',
                500 => 'Google server error',
            ];
            
            if ( isset( $http_errors[ $code ] ) ) {
                $error_msg = $http_errors[ $code ];
            }
            
            return new WP_Error( 'gemini_api_error', "HTTP $code: " . $error_msg );
        }

        // Validate response structure
        if ( ! isset( $body['candidates'][0]['content']['parts'][0]['text'] ) ) {
            return new WP_Error( 'invalid_response', 'Unexpected Gemini API response format' );
        }

        return trim( $body['candidates'][0]['content']['parts'][0]['text'] ?? '' );
    }
}

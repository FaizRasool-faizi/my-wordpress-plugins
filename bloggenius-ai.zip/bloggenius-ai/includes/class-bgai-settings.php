<?php
defined( 'ABSPATH' ) || exit;

class BGAI_Settings {
    const OPTION_KEY = 'bgai_settings';

    public static function init() {
        add_action( 'admin_init', [ __CLASS__, 'register_settings' ] );
    }

    public static function register_settings() {
        register_setting( 'bgai_settings_group', self::OPTION_KEY, [
            'sanitize_callback' => [ __CLASS__, 'sanitize' ],
        ] );
    }

    public static function get_all() {
        return wp_parse_args( get_option( self::OPTION_KEY, [] ), self::defaults() );
    }

    public static function get( $key, $fallback = '' ) {
        $settings = self::get_all();
        return isset( $settings[ $key ] ) ? $settings[ $key ] : $fallback;
    }

    public static function defaults() {
        return [
            'api_key'       => '',
            'ai_model'      => 'llama-3.3-70b-versatile',
            'ai_provider'   => 'groq',
            'post_status'   => 'draft',
            'post_author'   => 1,
            'post_category' => '',
        ];
    }

    public static function sanitize( $input ) {
        $clean = [];
        $clean['api_key']       = sanitize_text_field( $input['api_key'] ?? '' );
        $clean['ai_model']      = sanitize_text_field( $input['ai_model'] ?? 'llama-3.3-70b-versatile' );
        $clean['ai_provider']   = sanitize_text_field( $input['ai_provider'] ?? 'groq' );
        $clean['post_status']   = in_array( $input['post_status'] ?? '', [ 'draft', 'publish', 'pending' ] ) ? $input['post_status'] : 'draft';
        $clean['post_author']   = absint( $input['post_author'] ?? 1 );
        $clean['post_category'] = absint( $input['post_category'] ?? 0 );
        return $clean;
    }
}

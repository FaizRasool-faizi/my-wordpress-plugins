﻿<?php
defined( 'ABSPATH' ) || exit;

class BGAI_Generator {

    public static function generate_post( $keyword, $options = [] ) {
        $tone       = sanitize_text_field( $options['tone']       ?? 'informative' );
        $word_count = intval( $options['word_count']              ?? 1200 );
        $language   = sanitize_text_field( $options['language']   ?? 'English' );
        $prompt     = self::build_full_prompt( $keyword, $tone, $word_count, $language );
        $result     = BGAI_API::request( $prompt, 3500 );
        if ( is_wp_error( $result ) ) return $result;
        return self::parse_full_response( $result, $keyword );
    }

    public static function generate_meta( $keyword, $content = '' ) {
        $context = $content ? 'Content excerpt: ' . wp_trim_words( strip_tags( $content ), 80 ) : '';
        $prompt  = "Write an SEO meta title (max 60 chars) and meta description (max 160 chars) for a blog post about: \"{$keyword}\". {$context}\n\nRespond in this exact JSON format:\n{\"meta_title\": \"...\", \"meta_description\": \"...\"}";
        $result  = BGAI_API::request( $prompt, 300 );
        if ( is_wp_error( $result ) ) return $result;
        $json = self::extract_json( $result );
        return $json ?: [ 'meta_title' => $keyword, 'meta_description' => '' ];
    }

    public static function suggest_images( $keyword ) {
        $prompt = "Suggest 5 specific, descriptive image search queries for a blog post about: \"{$keyword}\". Return as a JSON array of strings: [\"query1\", \"query2\", ...]";
        $result = BGAI_API::request( $prompt, 300 );
        if ( is_wp_error( $result ) ) return $result;
        $json = self::extract_json( $result );
        return is_array( $json ) ? $json : [];
    }

    private static function build_full_prompt( $keyword, $tone, $word_count, $language ) {
        return "You are an expert SEO content strategist. Generate a complete, SEO-optimized blog post about: \"{$keyword}\".\n\nRequirements:\n- Language: {$language}\n- Tone: {$tone}\n- Target word count: ~{$word_count} words\n- Include LSI keywords naturally\n- Use H2 and H3 headings\n- Short paragraphs (2-4 sentences)\n- Include FAQ section\n\nReturn ONLY valid JSON (no markdown, no code fences):\n{\"title\":\"SEO title 60-70 chars\",\"slug\":\"url-slug\",\"meta_title\":\"meta title max 60 chars\",\"meta_description\":\"meta desc 120-160 chars\",\"focus_keyword\":\"{$keyword}\",\"excerpt\":\"2-3 sentence excerpt\",\"content\":\"Full HTML using h2 h3 p ul ol strong em tags\",\"tags\":[\"tag1\",\"tag2\",\"tag3\",\"tag4\",\"tag5\"],\"image_queries\":[\"query1\",\"query2\",\"query3\"],\"estimated_read_time\":\"X min read\"}";
    }

    private static function parse_full_response( $raw, $keyword ) {
        $data = self::extract_json( $raw );
        if ( ! $data || ! isset( $data['content'] ) ) {
            return [
                'title'               => ucwords( $keyword ) . ' - Complete Guide',
                'slug'                => sanitize_title( $keyword ),
                'meta_title'          => ucwords( $keyword ) . ' | Complete Guide',
                'meta_description'    => 'Learn everything about ' . $keyword . ' in this comprehensive guide.',
                'focus_keyword'       => $keyword,
                'excerpt'             => '',
                'content'             => wp_kses_post( $raw ),
                'tags'                => [],
                'image_queries'       => [ $keyword ],
                'estimated_read_time' => '5 min read',
            ];
        }
        $data['title']               = sanitize_text_field( $data['title'] ?? '' );
        $data['slug']                = sanitize_title( $data['slug'] ?? $keyword );
        $data['meta_title']          = sanitize_text_field( $data['meta_title'] ?? '' );
        $data['meta_description']    = sanitize_text_field( $data['meta_description'] ?? '' );
        $data['focus_keyword']       = sanitize_text_field( $data['focus_keyword'] ?? $keyword );
        $data['excerpt']             = sanitize_text_field( $data['excerpt'] ?? '' );
        $data['content']             = wp_kses_post( $data['content'] ?? '' );
        $data['tags']                = array_map( 'sanitize_text_field', (array) ( $data['tags'] ?? [] ) );
        $data['image_queries']       = array_map( 'sanitize_text_field', (array) ( $data['image_queries'] ?? [] ) );
        $data['estimated_read_time'] = sanitize_text_field( $data['estimated_read_time'] ?? '5 min read' );
        return $data;
    }

    private static function extract_json( $raw ) {
        $cleaned = preg_replace( '/^```(?:json)?\s*/i', '', trim( $raw ) );
        $cleaned = preg_replace( '/\s*```$/', '', $cleaned );
        if ( preg_match( '/(\{[\s\S]*\}|\[[\s\S]*\])/m', $cleaned, $m ) ) {
            $decoded = json_decode( $m[1], true );
            if ( json_last_error() === JSON_ERROR_NONE ) return $decoded;
        }
        $decoded = json_decode( $cleaned, true );
        if ( json_last_error() === JSON_ERROR_NONE ) return $decoded;
        return null;
    }
}

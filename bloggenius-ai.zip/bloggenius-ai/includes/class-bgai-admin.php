<?php
defined( 'ABSPATH' ) || exit;

class BGAI_Admin {

    public static function init() {
        add_action( 'admin_menu',            [ __CLASS__, 'register_menus' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_assets' ] );
    }

    public static function register_menus() {
        $icon = 'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>' );

        add_menu_page(
            __( 'BlogGenius AI', 'bloggenius-ai' ),
            __( 'BlogGenius AI', 'bloggenius-ai' ),
            'edit_posts',
            'bloggenius-ai',
            [ __CLASS__, 'render_generator_page' ],
            $icon,
            25
        );

        add_submenu_page( 'bloggenius-ai', __( 'Generate Post', 'bloggenius-ai' ), __( 'Generate Post', 'bloggenius-ai' ), 'edit_posts', 'bloggenius-ai', [ __CLASS__, 'render_generator_page' ] );
        add_submenu_page( 'bloggenius-ai', __( 'Settings', 'bloggenius-ai' ), __( 'Settings', 'bloggenius-ai' ), 'manage_options', 'bloggenius-ai-settings', [ __CLASS__, 'render_settings_page' ] );
    }

    public static function enqueue_assets( $hook ) {
        $allowed = [ 'toplevel_page_bloggenius-ai', 'bloggenius-ai_page_bloggenius-ai-settings' ];
        if ( ! in_array( $hook, $allowed, true ) ) return;

        wp_enqueue_style( 'bgai-admin', BGAI_ASSETS_URL . 'css/admin.css', [], BGAI_VERSION );
        wp_enqueue_script( 'bgai-admin', BGAI_ASSETS_URL . 'js/admin.js', [ 'jquery' ], BGAI_VERSION, true );
        wp_localize_script( 'bgai-admin', 'BGAI', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'bgai_nonce' ),
            'strings'  => [
                'generating'   => __( 'Generating your content...', 'bloggenius-ai' ),
                'publishing'   => __( 'Publishing post...', 'bloggenius-ai' ),
                'saving_draft' => __( 'Saving draft...', 'bloggenius-ai' ),
                'success'      => __( 'Content generated successfully!', 'bloggenius-ai' ),
                'error'        => __( 'Something went wrong. Please try again.', 'bloggenius-ai' ),
                'copied'       => __( 'Copied!', 'bloggenius-ai' ),
            ],
        ] );
    }

    public static function render_generator_page() {
        $categories  = get_categories( [ 'hide_empty' => false ] );
        $has_api_key = ! empty( BGAI_Settings::get( 'api_key' ) );
        include BGAI_DIR . 'views' . DIRECTORY_SEPARATOR . 'generator.php';
    }

    public static function render_settings_page() {
        $settings   = BGAI_Settings::get_all();
        $categories = get_categories( [ 'hide_empty' => false ] );
        $authors    = get_users( [ 'role__in' => [ 'administrator', 'editor', 'author' ] ] );
        include BGAI_DIR . 'views' . DIRECTORY_SEPARATOR . 'settings.php';
    }
}

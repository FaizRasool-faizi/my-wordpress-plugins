<?php
defined( 'ABSPATH' ) || exit;

class BGAI_Ajax {

    public static function init() {
        $actions = [ 'bgai_generate_post', 'bgai_publish_post', 'bgai_save_draft', 'bgai_generate_meta', 'bgai_suggest_images', 'bgai_test_connection' ];
        foreach ( $actions as $action ) {
            add_action( 'wp_ajax_' . $action, [ __CLASS__, str_replace( 'bgai_', 'handle_', $action ) ] );
        }
    }

    public static function handle_generate_post() {
        self::verify_nonce();
        $keyword    = sanitize_text_field( $_POST['keyword'] ?? '' );
        $tone       = sanitize_text_field( $_POST['tone'] ?? 'informative' );
        $word_count = intval( $_POST['word_count'] ?? 1200 );
        $language   = sanitize_text_field( $_POST['language'] ?? 'English' );
        if ( empty( $keyword ) ) wp_send_json_error( [ 'message' => __( 'Keyword is required.', 'bloggenius-ai' ) ] );
        $result = BGAI_Generator::generate_post( $keyword, compact( 'tone', 'word_count', 'language' ) );
        if ( is_wp_error( $result ) ) wp_send_json_error( [ 'message' => $result->get_error_message() ] );
        wp_send_json_success( $result );
    }

    public static function handle_publish_post() {
        self::verify_nonce();
        $title      = sanitize_text_field( $_POST['title'] ?? '' );
        $content    = wp_kses_post( wp_unslash( $_POST['content'] ?? '' ) );
        $excerpt    = sanitize_text_field( $_POST['excerpt'] ?? '' );
        $raw_tags   = stripslashes( $_POST['tags'] ?? '[]' );
        $tags       = array_map( 'sanitize_text_field', json_decode( $raw_tags, true ) ?: [] );
        $status     = ( isset( $_POST['post_status'] ) && $_POST['post_status'] === 'publish' ) ? 'publish' : 'draft';
        $meta_title = sanitize_text_field( $_POST['meta_title'] ?? '' );
        $meta_desc  = sanitize_text_field( $_POST['meta_description'] ?? '' );
        $focus_kw   = sanitize_text_field( $_POST['focus_keyword'] ?? '' );
        $category   = absint( $_POST['category'] ?? 0 );
        $author     = absint( BGAI_Settings::get( 'post_author', get_current_user_id() ) );

        if ( empty( $title ) || empty( $content ) ) wp_send_json_error( [ 'message' => __( 'Title and content are required.', 'bloggenius-ai' ) ] );

        $post_data = [
            'post_title'   => $title,
            'post_content' => $content,
            'post_excerpt' => $excerpt,
            'post_status'  => $status,
            'post_author'  => $author,
            'post_type'    => 'post',
        ];
        if ( $category ) $post_data['post_category'] = [ $category ];

        $post_id = wp_insert_post( $post_data, true );
        if ( is_wp_error( $post_id ) ) wp_send_json_error( [ 'message' => $post_id->get_error_message() ] );

        if ( ! empty( $tags ) ) wp_set_post_tags( $post_id, $tags, false );
        if ( $meta_title ) update_post_meta( $post_id, '_bgai_meta_title', $meta_title );
        if ( $meta_desc )  update_post_meta( $post_id, '_bgai_meta_description', $meta_desc );
        if ( $focus_kw )   update_post_meta( $post_id, '_bgai_focus_keyword', $focus_kw );
        if ( defined( 'WPSEO_VERSION' ) ) {
            update_post_meta( $post_id, '_yoast_wpseo_title', $meta_title );
            update_post_meta( $post_id, '_yoast_wpseo_metadesc', $meta_desc );
            update_post_meta( $post_id, '_yoast_wpseo_focuskw', $focus_kw );
        }
        if ( class_exists( 'RankMath' ) ) {
            update_post_meta( $post_id, 'rank_math_title', $meta_title );
            update_post_meta( $post_id, 'rank_math_description', $meta_desc );
            update_post_meta( $post_id, 'rank_math_focus_keyword', $focus_kw );
        }
        wp_send_json_success( [
            'post_id'     => $post_id,
            'edit_url'    => get_edit_post_link( $post_id, 'raw' ),
            'preview_url' => get_permalink( $post_id ),
            'message'     => $status === 'publish' ? __( 'Post published successfully!', 'bloggenius-ai' ) : __( 'Post saved as draft.', 'bloggenius-ai' ),
        ] );
    }

    public static function handle_save_draft() {
        $_POST['post_status'] = 'draft';
        self::handle_publish_post();
    }

    public static function handle_generate_meta() {
        self::verify_nonce();
        $keyword = sanitize_text_field( $_POST['keyword'] ?? '' );
        $content = wp_kses_post( wp_unslash( $_POST['content'] ?? '' ) );
        if ( empty( $keyword ) ) wp_send_json_error( [ 'message' => __( 'Keyword is required.', 'bloggenius-ai' ) ] );
        $result = BGAI_Generator::generate_meta( $keyword, $content );
        if ( is_wp_error( $result ) ) wp_send_json_error( [ 'message' => $result->get_error_message() ] );
        wp_send_json_success( $result );
    }

    public static function handle_suggest_images() {
        self::verify_nonce();
        $keyword = sanitize_text_field( $_POST['keyword'] ?? '' );
        if ( empty( $keyword ) ) wp_send_json_error( [ 'message' => __( 'Keyword is required.', 'bloggenius-ai' ) ] );
        $result = BGAI_Generator::suggest_images( $keyword );
        if ( is_wp_error( $result ) ) wp_send_json_error( [ 'message' => $result->get_error_message() ] );
        wp_send_json_success( [ 'queries' => $result ] );
    }

    public static function handle_test_connection() {
        // Verify user permissions and nonce
        if ( ! check_ajax_referer( 'bgai_nonce', 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => __( 'Security check failed. Please refresh and try again.', 'bloggenius-ai' ) ], 403 );
            wp_die();
        }
        
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'bloggenius-ai' ) ], 403 );
            wp_die();
        }
        
        $api_key = isset( $_POST['api_key'] ) ? sanitize_text_field( wp_unslash( $_POST['api_key'] ) ) : '';
        $provider = isset( $_POST['provider'] ) ? sanitize_text_field( wp_unslash( $_POST['provider'] ) ) : 'groq';
        
        if ( empty( $api_key ) ) {
            wp_send_json_error( [ 'message' => __( 'API Key is required.', 'bloggenius-ai' ) ] );
            wp_die();
        }

        // Test with a simple prompt
        $test_prompt = 'Say "API Connection Successful" in exactly 3 words.';
        $result = self::test_api_connection( $api_key, $provider, $test_prompt );
        
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( [ 
                'message' => '❌ Connection Failed: ' . $result->get_error_message(),
                'error_code' => $result->get_error_code()
            ] );
            wp_die();
        }
        
        wp_send_json_success( [ 
            'message' => '✅ API Connection Successful! Your key is valid.',
            'response' => wp_trim_words( $result, 20 )
        ] );
        wp_die();
    }

    private static function test_api_connection( $api_key, $provider, $prompt ) {
        switch ( $provider ) {
            case 'groq':
                return self::test_groq_connection( $api_key, $prompt );
            case 'gemini':
                return self::test_gemini_connection( $api_key, $prompt );
            default:
                return new WP_Error( 'unknown_provider', __( 'Unknown provider.', 'bloggenius-ai' ) );
        }
    }

    private static function test_groq_connection( $api_key, $prompt ) {
        $body = wp_json_encode( [
            'model'      => 'llama-3.3-70b-versatile',
            'messages'   => [ [ 'role' => 'user', 'content' => $prompt ] ],
            'max_tokens' => 50,
        ] );
        
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return new WP_Error( 'json_encode_error', 'Failed to encode request body: ' . json_last_error_msg() );
        }

        $args = [
            'timeout'     => 45,
            'redirection' => 5,
            'httpversion' => '1.1',
            'user-agent'  => 'BlogGenius-AI/1.0',
            'blocking'    => true,
            'headers'     => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $api_key,
            ],
            'body'        => $body,
            'sslverify'   => false, // Local XAMPP environment
        ];

        $response = wp_remote_post( 'https://api.groq.com/openai/v1/chat/completions', $args );

        // Handle WP_Error from network issues
        if ( is_wp_error( $response ) ) {
            return self::format_network_error( $response );
        }

        // Get response details
        $response_code = wp_remote_retrieve_response_code( $response );
        $response_body = wp_remote_retrieve_body( $response );
        $response_headers = wp_remote_retrieve_headers( $response );

        // Validate response code
        if ( $response_code !== 200 ) {
            $error_msg = self::parse_groq_error( $response_code, $response_body );
            return new WP_Error( 'groq_api_error', $error_msg );
        }

        // Parse JSON response
        $body_decoded = json_decode( $response_body, true );
        
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return new WP_Error( 'response_parse_error', 'Invalid JSON response: ' . json_last_error_msg() );
        }

        if ( ! isset( $body_decoded['choices'][0]['message']['content'] ) ) {
            return new WP_Error( 'invalid_response_format', 'API returned unexpected response format' );
        }

        return $body_decoded['choices'][0]['message']['content'];
    }

    private static function parse_groq_error( $code, $response_body ) {
        $body = json_decode( $response_body, true );
        
        $error_details = '';
        
        if ( is_array( $body ) && isset( $body['error'] ) ) {
            if ( is_array( $body['error'] ) ) {
                $error_details = $body['error']['message'] ?? $body['error']['type'] ?? 'Unknown error';
            } else {
                $error_details = (string) $body['error'];
            }
        }

        $error_messages = [
            400 => 'Invalid request (Bad Request)',
            401 => 'Invalid API key or unauthorized',
            403 => 'Access forbidden',
            404 => 'API endpoint not found',
            429 => 'Rate limit exceeded - try again later',
            500 => 'Groq server error',
            502 => 'Bad gateway',
            503 => 'Service unavailable',
            504 => 'Gateway timeout',
        ];

        $base_msg = $error_messages[ $code ] ?? "HTTP Error $code";
        
        return $base_msg . ( $error_details ? ' - ' . $error_details : '' );
    }

    private static function test_gemini_connection( $api_key, $prompt ) {
        $endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={$api_key}";
        $body = wp_json_encode( [
            'contents'         => [ [ 'parts' => [ [ 'text' => $prompt ] ] ] ],
            'generationConfig' => [ 'maxOutputTokens' => 50, 'temperature' => 0.7 ],
        ] );

        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return new WP_Error( 'json_encode_error', 'Failed to encode request body: ' . json_last_error_msg() );
        }

        $args = [
            'timeout'     => 45,
            'redirection' => 5,
            'httpversion' => '1.1',
            'user-agent'  => 'BlogGenius-AI/1.0',
            'blocking'    => true,
            'headers'     => [
                'Content-Type' => 'application/json',
            ],
            'body'        => $body,
            'sslverify'   => false, // Local XAMPP environment
        ];

        $response = wp_remote_post( $endpoint, $args );

        // Handle WP_Error from network issues
        if ( is_wp_error( $response ) ) {
            return self::format_network_error( $response );
        }

        // Get response details
        $response_code = wp_remote_retrieve_response_code( $response );
        $response_body = wp_remote_retrieve_body( $response );
        $response_headers = wp_remote_retrieve_headers( $response );

        // Validate response code
        if ( $response_code !== 200 ) {
            $error_msg = self::parse_gemini_error( $response_code, $response_body );
            return new WP_Error( 'gemini_api_error', $error_msg );
        }

        // Parse JSON response
        $body_decoded = json_decode( $response_body, true );
        
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return new WP_Error( 'response_parse_error', 'Invalid JSON response: ' . json_last_error_msg() );
        }

        if ( ! isset( $body_decoded['candidates'][0]['content']['parts'][0]['text'] ) ) {
            return new WP_Error( 'invalid_response_format', 'Gemini returned unexpected response format' );
        }

        return $body_decoded['candidates'][0]['content']['parts'][0]['text'];
    }

    private static function parse_gemini_error( $code, $response_body ) {
        $body = json_decode( $response_body, true );
        
        $error_details = '';
        
        if ( is_array( $body ) && isset( $body['error'] ) ) {
            if ( is_array( $body['error'] ) ) {
                $error_details = $body['error']['message'] ?? $body['error']['code'] ?? 'Unknown error';
            } else {
                $error_details = (string) $body['error'];
            }
        }

        $error_messages = [
            400 => 'Invalid request (Bad Request)',
            401 => 'Unauthenticated - Invalid API key',
            403 => 'Permission denied',
            404 => 'API endpoint not found',
            429 => 'Rate limit exceeded',
            500 => 'Google server error',
            503 => 'Service unavailable',
        ];

        $base_msg = $error_messages[ $code ] ?? "HTTP Error $code";
        
        return $base_msg . ( $error_details ? ' - ' . $error_details : '' );
    }

    private static function format_network_error( $wp_error ) {
        $error_code = $wp_error->get_error_code();
        $error_message = $wp_error->get_error_message();
        
        // Map cURL and network specific errors
        $error_map = [
            'http_request_failed'   => 'Network Connection Failed',
            'ssl_verify_failed'     => 'SSL Certificate Verification Failed (For local XAMPP, this is normal)',
            'stream_context_error'  => 'Stream Context Error',
            'fsockopen_read_error'  => 'Socket Read Error',
            'fsockopen_connect_error' => 'Socket Connection Failed',
            'curl_error'            => 'cURL Request Error',
        ];

        // Check if error message contains common cURL errors
        $detailed_error = '';
        
        if ( strpos( $error_message, 'cURL error' ) !== false ) {
            $detailed_error = $error_message;
        } elseif ( strpos( $error_message, 'SSL' ) !== false || strpos( $error_message, 'certificate' ) !== false ) {
            $detailed_error = 'SSL Certificate verification failed - Local XAMPP environment detected';
        } elseif ( strpos( $error_message, 'connection' ) !== false || strpos( $error_message, 'refused' ) !== false ) {
            $detailed_error = 'Connection refused - Check if you are connected to the internet';
        } elseif ( strpos( $error_message, 'timeout' ) !== false ) {
            $detailed_error = 'Request timeout - Groq API took too long to respond';
        } elseif ( strpos( $error_message, 'DNS' ) !== false || strpos( $error_message, 'resolve' ) !== false ) {
            $detailed_error = 'DNS resolution failed - Cannot reach api.groq.com or generativelanguage.googleapis.com';
        } else {
            $detailed_error = $error_message;
        }

        $friendly_msg = $error_map[ $error_code ] ?? 'Network Error';
        
        return new WP_Error( 'network_error', $friendly_msg . ': ' . $detailed_error );
    }

    private static function verify_nonce() {
        if ( ! check_ajax_referer( 'bgai_nonce', 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => __( 'Security check failed.', 'bloggenius-ai' ) ], 403 );
            wp_die();
        }
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'bloggenius-ai' ) ], 403 );
            wp_die();
        }
    }
}

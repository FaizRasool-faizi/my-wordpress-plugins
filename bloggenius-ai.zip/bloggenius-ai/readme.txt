=== BlogGenius AI ===
Contributors: bloggenius
Tags: AI, blog, SEO, content generation, OpenAI, Gemini, GPT-4
Requires at least: 5.8
Tested up to: 6.5
=== BlogGenius AI ===
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Generate complete SEO-optimized blog posts using AI (OpenAI GPT-4 or Google Gemini) directly from your WordPress dashboard.

== Description ==

**BlogGenius AI** is a powerful WordPress plugin that lets you generate complete, SEO-optimized blog posts in seconds using the latest AI models.

= Features =
* Keyword-based blog post generation
* AI-generated title, headings, and full HTML content
* Auto-generated SEO meta title & meta description
* Live SERP (Google) preview
* Image search suggestions (linked to Unsplash, Pexels, Pixabay)
* Real-time SEO score analysis
* HTML editor + visual preview tab
* Auto-generated tags
* Yoast SEO & Rank Math compatible
* One-click publish or save as draft
* Supports OpenAI (GPT-4o, GPT-4o-mini, GPT-3.5) and Google Gemini
* Multi-language support
* Tone selection (informative, conversational, professional, persuasive, casual)
* Word count target (500–3000 words)

== Installation ==

1. Upload the `bloggenius-ai` folder to `/wp-content/plugins/`.
2. Activate the plugin in **Plugins > Installed Plugins**.
3. Go to **BlogGenius AI > Settings** and enter your API key.
4. Navigate to **BlogGenius AI > Generate Post** and start creating content!

== Frequently Asked Questions ==

= Which AI provider should I use? =
Both OpenAI and Google Gemini produce excellent results. GPT-4o-mini (OpenAI) and Gemini 1.5 Flash are the recommended cost-effective options.

= Where do I get an API key? =
- OpenAI: https://platform.openai.com/api-keys
- Google Gemini: https://aistudio.google.com/app/apikey

= Is this compatible with Yoast SEO? =
Yes! When Yoast SEO is active, the generated meta title, description, and focus keyword are automatically saved to Yoast's meta fields.

= Is it compatible with Rank Math? =
Yes, Rank Math compatibility is built in.

== Changelog ==

= 1.0.0 =
* Initial release.

/**
 * BlogGenius AI — Admin JavaScript
 * Handles all AJAX interactions, UI state management, and live previews.
 */
(function ($) {
    'use strict';

    /* =========================================================
       State
       ========================================================= */
    const STATE = {
        generated: null,  // Holds last generated post data
        tags: [],
    };

    /* =========================================================
       DOM Refs (cached once on DOM ready)
       ========================================================= */
    let $form, $generateBtn, $output, $empty, $loader;

    /* =========================================================
       Init
       ========================================================= */
    $(function () {
        $form = $('#bgai-generator-form');
        $generateBtn = $('#bgai-generate-btn');
        $output = $('#bgai-output');
        $empty = $('#bgai-empty');
        $loader = $('#bgai-loader');

        bindEvents();
        initRangeSlider();
        initCharCount();
        initTabs();
        initSettingsPage();
    });

    /* =========================================================
       Settings Page - Test Connection
       ========================================================= */
    function initSettingsPage() {
        // Only initialize if on settings page
        if ( ! $('body').hasClass('bloggenius-ai_page_bloggenius-ai-settings') && ! $('#bgai-test-connection').length ) {
            return;
        }

        // Test Connection Button Handler
        $(document).on('click', '#bgai-test-connection', function() {
            var apiKey = $('#bgai-api-key').val().trim();
            var provider = $('input[name="bgai_settings[ai_provider]"]' + ':checked').val() || 'groq';
            var $btn = $(this);
            var $result = $('#bgai-test-result');

            if ( !apiKey ) {
                $result.html('⚠️ Please enter an API Key first').css('background', '#fff3cd').css('color', '#856404').show();
                return;
            }

            $btn.prop('disabled', true).text('🔄 Testing...');
            $result.html('🔄 Testing connection...').css('background', '#e7f3ff').css('color', '#004085').show();

            $.ajax({
                url: BGAI.ajax_url,
                method: 'POST',
                dataType: 'json',
                data: {
                    action: 'bgai_test_connection',
                    nonce: BGAI.nonce,
                    api_key: apiKey,
                    provider: provider
                },
                timeout: 30000,
                success: function(response) {
                    if ( response.success ) {
                        $result.html( response.data.message ).css('background', '#d4edda').css('color', '#155724').show();
                    } else {
                        var errMsg = response.data.message || response.data || '❌ Connection failed';
                        $result.html( errMsg ).css('background', '#f8d7da').css('color', '#721c24').show();
                    }
                },
                error: function(xhr, status, error) {
                    var errMsg = '❌ Network error';
                    var debugInfo = '';
                    
                    if ( status === 'timeout' ) {
                        errMsg = '❌ Request timed out (>30s). Please try again.';
                    } else if ( status === 'parsererror' ) {
                        errMsg = '❌ Invalid server response. Server may be having issues.';
                        debugInfo = 'API returned invalid JSON. Response: ' + xhr.responseText.substring(0, 100);
                    } else if ( xhr.status === 0 ) {
                        errMsg = '❌ Cannot reach server. Check your internet connection.';
                    } else if ( xhr.status >= 500 ) {
                        errMsg = '❌ Server error (' + xhr.status + '). Server is having issues.';
                    } else if ( xhr.status >= 400 ) {
                        errMsg = '❌ Client error (' + xhr.status + '). ' + xhr.statusText;
                    } else {
                        errMsg = '❌ Request failed: ' + (error || xhr.statusText);
                    }
                    
                    $result.html( errMsg ).css('background', '#f8d7da').css('color', '#721c24').show();
                    if (debugInfo) console.warn(debugInfo);
                    console.error('Test connection error:', status, error, xhr);
                },
                complete: function() {
                    $btn.prop('disabled', false).text('🧪 Test Connection');
                }
            });
        });
    }

    /* =========================================================
       Bind all UI events
       ========================================================= */
    function bindEvents() {
        // Form submit → generate
        $form.on('submit', onGenerate);

        // Publish / Draft
        $('#bgai-publish-btn').on('click', function () { onPublish('publish'); });
        $('#bgai-save-draft-btn').on('click', function () { onPublish('draft'); });

        // Regenerate meta
        $('#bgai-regen-meta-btn').on('click', onRegenMeta);

        // Copy buttons
        $(document).on('click', '.bgai-copy-btn', onCopyClick);

        // Live SERP preview
        $(document).on('input', '#bgai-meta-title', function () {
            const val = $(this).val();
            $('#bgai-serp-title-preview').text(val);
            updateCharCount('bgai-meta-title-count', val.length, 60);
        });

        $(document).on('input', '#bgai-meta-desc', function () {
            const val = $(this).val();
            $('#bgai-serp-desc-preview').text(val);
            updateCharCount('bgai-meta-desc-count', val.length, 160);
        });

        $(document).on('input', '#bgai-title-input', function () {
            const slug = slugify($(this).val());
            $('#bgai-slug-display').text(slug);
            $('#bgai-serp-slug').text(slug);
        });

        // Content → preview tab sync
        $(document).on('input', '#bgai-content', function () {
            $('#bgai-preview-content').html($(this).val());
        });
    }

    /* =========================================================
       Generate Post
       ========================================================= */
    function onGenerate(e) {
        e.preventDefault();

        const keyword = $('#bgai-keyword').val().trim();
        if (!keyword) {
            showError('Please enter a keyword.');
            return;
        }

        setLoadingState(true);
        animateLoadingSteps();

        $.ajax({
            url: BGAI.ajax_url,
            method: 'POST',
            data: {
                action: 'bgai_generate_post',
                nonce: BGAI.nonce,
                keyword: keyword,
                tone: $('#bgai-tone').val(),
                word_count: $('#bgai-word-count').val(),
                language: $('#bgai-language').val(),
            },
            timeout: 120000,
            success: function (res) {
                if (res.success) {
                    STATE.generated = res.data;
                    populateOutput(res.data);
                    showOutput();
                    showToast(BGAI.strings.success);
                    computeSeoScore(res.data);
                } else {
                    showError(res.data.message || BGAI.strings.error);
                }
            },
            error: function (xhr, status, error) {
                let errorMsg = BGAI.strings.error;
                
                if (status === 'timeout') {
                    errorMsg = '⏱️ Request timed out (>2 mins). Groq API is responding slowly. Please try again.';
                } else if (status === 'error' || status === 'parsererror') {
                    errorMsg = '❌ Network Error: Cannot reach Groq API. Check:\n• Internet connection\n• Firewall/VPN blocking\n• API key is valid';
                } else if (error) {
                    errorMsg = '❌ Error: ' + error;
                }
                
                showError(errorMsg);
            },
            complete: function () {
                setLoadingState(false);
            },
        });
    }

    /* =========================================================
       Populate Output Fields
       ========================================================= */
    function populateOutput(data) {
        // Title
        $('#bgai-title-input').val(data.title || '');
        $('#bgai-slug-display').text(data.slug || slugify(data.title));
        $('#bgai-read-time').html(
            '<svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg> ' +
            (data.estimated_read_time || '5 min read')
        );

        // SEO Meta
        $('#bgai-meta-title').val(data.meta_title || '').trigger('input');
        $('#bgai-meta-desc').val(data.meta_description || '').trigger('input');
        $('#bgai-focus-kw').val(data.focus_keyword || '');

        // SERP preview
        $('#bgai-serp-slug').text(data.slug || slugify(data.title));
        $('#bgai-serp-title-preview').text(data.meta_title || data.title);
        $('#bgai-serp-desc-preview').text(data.meta_description || '');

        // Content
        $('#bgai-content').val(data.content || '').trigger('input');

        // Excerpt
        $('#bgai-excerpt').val(data.excerpt || '');

        // Tags
        STATE.tags = data.tags || [];
        renderTags();

        // Image suggestions
        renderImageSuggestions(data.image_queries || []);

        // Default publish status from settings
        const statusEl = document.getElementById('bgai-post-status');
        if (statusEl && BGAI.default_status) {
            statusEl.value = BGAI.default_status;
        }
    }

    /* =========================================================
       Publish / Save Draft
       ========================================================= */
    function onPublish(forceStatus) {
        const title = $('#bgai-title-input').val().trim();
        const content = $('#bgai-content').val().trim();

        if (!title || !content) {
            showError('Title and content are required before publishing.');
            return;
        }

        const status = forceStatus || $('#bgai-post-status').val() || 'draft';
        const btnText = status === 'publish' ? BGAI.strings.publishing : BGAI.strings.saving_draft;

        setBtnLoading('#bgai-publish-btn', btnText);
        setBtnLoading('#bgai-save-draft-btn', '…');

        $.ajax({
            url: BGAI.ajax_url,
            method: 'POST',
            data: {
                action: 'bgai_publish_post',
                nonce: BGAI.nonce,
                title: title,
                content: content,
                excerpt: $('#bgai-excerpt').val(),
                tags: JSON.stringify(STATE.tags),
                post_status: status,
                meta_title: $('#bgai-meta-title').val(),
                meta_description: $('#bgai-meta-desc').val(),
                focus_keyword: $('#bgai-focus-kw').val(),
                category: $('#bgai-category').val(),
            },
            success: function (res) {
                if (res.success) {
                    showToast(res.data.message, res.data.edit_url);
                } else {
                    showError(res.data.message || BGAI.strings.error);
                }
            },
            error: function () { showError(BGAI.strings.error); },
            complete: function () {
                resetBtn('#bgai-publish-btn', '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg> Publish to WordPress');
                resetBtn('#bgai-save-draft-btn', '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg> Save Draft');
            },
        });
    }

    /* =========================================================
       Regenerate Meta
       ========================================================= */
    function onRegenMeta() {
        const keyword = $('#bgai-focus-kw').val() || $('#bgai-keyword').val();
        if (!keyword) { showError('Enter a keyword first.'); return; }

        const $btn = $('#bgai-regen-meta-btn');
        $btn.prop('disabled', true).text('Regenerating…');

        $.ajax({
            url: BGAI.ajax_url,
            method: 'POST',
            data: {
                action: 'bgai_generate_meta',
                nonce: BGAI.nonce,
                keyword: keyword,
                content: $('#bgai-content').val().substring(0, 2000),
            },
            success: function (res) {
                if (res.success) {
                    $('#bgai-meta-title').val(res.data.meta_title).trigger('input');
                    $('#bgai-meta-desc').val(res.data.meta_description).trigger('input');
                    showToast('Meta regenerated!');
                } else {
                    showError(res.data.message);
                }
            },
            error: function () { showError(BGAI.strings.error); },
            complete: function () {
                $btn.prop('disabled', false).html('<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg> Regenerate');
            },
        });
    }

    /* =========================================================
       Tags
       ========================================================= */
    function renderTags() {
        const $container = $('#bgai-tags-container').empty();
        if (!STATE.tags.length) {
            $container.html('<span style="color:#9CA3AF;font-size:13px;">No tags generated.</span>');
            return;
        }
        STATE.tags.forEach(function (tag, i) {
            $('<div>', { class: 'bgai-tag', 'data-index': i })
                .html(tag + ' <span class="bgai-tag-x">&times;</span>')
                .on('click', function () {
                    STATE.tags.splice(i, 1);
                    renderTags();
                })
                .appendTo($container);
        });
    }

    /* =========================================================
       Image Suggestions
       ========================================================= */
    function renderImageSuggestions(queries) {
        const $grid = $('#bgai-image-grid').empty();

        if (!queries || !queries.length) {
            $grid.html('<div class="bgai-image-placeholder"><p>No image suggestions generated.</p></div>');
            return;
        }

        queries.forEach(function (query) {
            const encodedQuery = encodeURIComponent(query);
            const pexelsUrl = 'https://www.pexels.com/search/' + encodedQuery + '/';
            const unsplashUrl = 'https://unsplash.com/s/photos/' + encodedQuery;
            const pixabayUrl = 'https://pixabay.com/images/search/' + encodedQuery + '/';

            // Use Unsplash's random demo image for thumbnail
            const thumbUrl = 'https://source.unsplash.com/320x180/?' + encodedQuery;

            const $card = $('<div>', { class: 'bgai-image-card bgai-fade-in' });
            $card.append(
                $('<img>', {
                    class: 'bgai-image-thumb',
                    src: thumbUrl,
                    alt: query,
                    loading: 'lazy',
                    onerror: "this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22320%22 height=%22180%22 fill=%22%23F3F4F6%22%3E%3Crect width=%22320%22 height=%22180%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-family=%22Arial%22 font-size=%2213%22 fill=%22%239CA3AF%22 text-anchor=%22middle%22 dy=%22.3em%22%3EImage%3C/text%3E%3C/svg%3E'",
                }),
                $('<div>', { class: 'bgai-image-query', text: query }),
                $('<div>', { class: 'bgai-image-links' }).append(
                    $('<a>', { class: 'bgai-image-link', href: unsplashUrl, target: '_blank', text: 'Unsplash' }),
                    $('<a>', { class: 'bgai-image-link', href: pexelsUrl, target: '_blank', text: 'Pexels' }),
                    $('<a>', { class: 'bgai-image-link', href: pixabayUrl, target: '_blank', text: 'Pixabay' })
                )
            );
            $grid.append($card);
        });
    }

    /* =========================================================
       SEO Score Calculator
       ========================================================= */
    function computeSeoScore(data) {
        const checks = [];
        let score = 0;

        function check(pass, warn, label) {
            const status = pass ? 'pass' : warn ? 'warn' : 'fail';
            if (pass) score += 14;
            else if (warn) score += 7;
            checks.push({ status, label });
        }

        const title = data.title || '';
        const metaT = data.meta_title || '';
        const metaD = data.meta_description || '';
        const content = (data.content || '').replace(/<[^>]+>/g, '');
        const keyword = (data.focus_keyword || '').toLowerCase();
        const wordCount = content.split(/\s+/).filter(Boolean).length;

        check(title.length >= 40 && title.length <= 70, title.length > 0 && title.length < 40, 'Title length (40-70 chars): ' + title.length + ' chars');
        check(metaT.length >= 30 && metaT.length <= 60, metaT.length > 0 && metaT.length < 30, 'Meta title (30-60 chars): ' + metaT.length + ' chars');
        check(metaD.length >= 120 && metaD.length <= 160, metaD.length > 0 && metaD.length < 120, 'Meta description (120-160 chars): ' + metaD.length + ' chars');
        check(keyword && metaT.toLowerCase().includes(keyword), false, 'Keyword in meta title');
        check(keyword && content.toLowerCase().includes(keyword), false, 'Keyword in content');
        check(wordCount >= 800, wordCount >= 500 && wordCount < 800, 'Word count: ~' + wordCount + ' words');
        check((data.tags || []).length >= 3, (data.tags || []).length > 0, 'Tags: ' + (data.tags || []).length + ' tags');

        score = Math.min(100, Math.round((score / 98) * 100));

        // Render score ring
        const circumference = 314;
        const offset = circumference - (score / 100) * circumference;
        const color = score >= 80 ? '#10B981' : score >= 60 ? '#F59E0B' : '#EF4444';

        $('#bgai-ring-fill').css({
            'stroke-dashoffset': offset,
            'stroke': color
        });
        animateNumber('#bgai-seo-score', 0, score, 1000);

        // Render checks list
        const $ul = $('#bgai-seo-checks').empty();
        checks.forEach(function (c) {
            const icon = c.status === 'pass' ? '✓' : c.status === 'warn' ? '!' : '✗';
            const cls = 'bgai-check-' + (c.status === 'pass' ? 'pass' : c.status === 'warn' ? 'warn' : 'fail');
            $ul.append(
                $('<li>', { class: 'bgai-seo-check' }).append(
                    $('<span>', { class: 'bgai-check-icon ' + cls, text: icon }),
                    $('<span>', { text: c.label })
                )
            );
        });

        $('#bgai-seo-panel').show();
    }

    function animateNumber(selector, from, to, duration) {
        const start = Date.now();
        const tick = setInterval(function () {
            const elapsed = Date.now() - start;
            const progress = Math.min(elapsed / duration, 1);
            const val = Math.round(from + (to - from) * easeOut(progress));
            $(selector).text(val);
            if (progress >= 1) clearInterval(tick);
        }, 16);
    }

    function easeOut(t) { return 1 - Math.pow(1 - t, 3); }

    /* =========================================================
       Loading State Helpers
       ========================================================= */
    function setLoadingState(loading) {
        if (loading) {
            $loader.show();
            $output.hide();
            $empty.hide();
            $generateBtn.prop('disabled', true);
            $generateBtn.find('span').text(BGAI.strings.generating);
        } else {
            $loader.hide();
            $generateBtn.prop('disabled', false);
            $generateBtn.find('span').text('Generate Blog Post');
        }
    }

    function showOutput() {
        $output.show().addClass('bgai-fade-in');
        $empty.hide();
        $loader.hide();
        // Smooth scroll to output
        $('html, body').animate({ scrollTop: $output.offset().top - 100 }, 400);
    }

    let stepTimer;
    function animateLoadingSteps() {
        const steps = ['#bgai-step-1', '#bgai-step-2', '#bgai-step-3', '#bgai-step-4'];
        let current = 0;

        steps.forEach(s => $(s).removeClass('active done'));
        $(steps[0]).addClass('active');
        current = 1;

        stepTimer = setInterval(function () {
            if (current >= steps.length) {
                clearInterval(stepTimer);
                return;
            }
            $(steps[current - 1]).removeClass('active').addClass('done');
            $(steps[current]).addClass('active');
            current++;
        }, Math.random() * 8000 + 10000); // Stagger each step 10-18s
    }

    /* =========================================================
       Tabs
       ========================================================= */
    function initTabs() {
        $(document).on('click', '.bgai-tab', function () {
            const tab = $(this).data('tab');
            $(this).siblings('.bgai-tab').removeClass('active');
            $(this).addClass('active');

            if (tab === 'preview') {
                $('#bgai-preview-content').html($('#bgai-content').val());
                $('#bgai-tab-html').removeClass('active');
                $('#bgai-tab-preview').addClass('active');
            } else {
                $('#bgai-tab-preview').removeClass('active');
                $('#bgai-tab-html').addClass('active');
            }
        });
    }

    /* =========================================================
       Copy
       ========================================================= */
    function onCopyClick() {
        const targetId = $(this).data('target');
        const $target = $('#' + targetId);
        const text = $target.val ? $target.val() : $target.text();

        navigator.clipboard.writeText(text).then(function () {
            const $btn = $(this);
            $btn.text(BGAI.strings.copied);
            setTimeout(function () {
                $btn.html('<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> Copy');
            }, 1800);
        }.bind(this));
    }

    /* =========================================================
       Range Slider
       ========================================================= */
    function initRangeSlider() {
        $(document).on('input', '#bgai-word-count', function () {
            $('#bgai-word-count-badge').text($(this).val());
            // Update fill gradient
            const val = (+this.value - +this.min) / (+this.max - +this.min) * 100;
            this.style.background = `linear-gradient(to right, var(--bgai-primary) ${val}%, var(--bgai-border) ${val}%)`;
        });

        // Fire once on load
        $('#bgai-word-count').trigger('input');
    }

    /* =========================================================
       Char Counters
       ========================================================= */
    function initCharCount() {
        $(document).on('input', '#bgai-meta-title', function () {
            updateCharCount('bgai-meta-title-count', $(this).val().length, 60);
        });
        $(document).on('input', '#bgai-meta-desc', function () {
            updateCharCount('bgai-meta-desc-count', $(this).val().length, 160);
        });
    }

    function updateCharCount(id, count, max) {
        const $el = $('#' + id);
        $el.text(count);
        $el.closest('.bgai-char-count').css('color',
            count > max ? 'var(--bgai-danger)' : count > max * 0.9 ? 'var(--bgai-warning)' : ''
        );
    }

    /* =========================================================
       Toasts
       ========================================================= */
    let toastTimer;
    function showToast(msg, link) {
        clearTimeout(toastTimer);
        const $toast = $('#bgai-toast');
        const $link = $('#bgai-toast-link');
        $('#bgai-toast-msg').text(msg);

        if (link) {
            $link.attr('href', link).show();
        } else {
            $link.hide();
        }

        $toast.addClass('show');
        toastTimer = setTimeout(function () { $toast.removeClass('show'); }, 5000);
    }

    let errTimer;
    function showError(msg) {
        clearTimeout(errTimer);
        const $toast = $('#bgai-toast-error');
        $('#bgai-toast-error-msg').text(msg);
        $toast.addClass('show');
        errTimer = setTimeout(function () { $toast.removeClass('show'); }, 6000);
        setLoadingState(false);
    }

    /* =========================================================
       Button helpers
       ========================================================= */
    function setBtnLoading(selector, text) {
        $(selector).prop('disabled', true).text(text);
    }

    function resetBtn(selector, html) {
        $(selector).prop('disabled', false).html(html);
    }

    /* =========================================================
       Utilities
       ========================================================= */
    function slugify(str) {
        return (str || '')
            .toLowerCase()
            .replace(/[^a-z0-9\s-]/g, '')
            .trim()
            .replace(/[\s_-]+/g, '-')
            .replace(/^-+|-+$/g, '');
    }

}(jQuery));

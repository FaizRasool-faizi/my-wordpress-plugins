<?php
/**
 * Plugin Name:       BlogGenius AI
 * Plugin URI:        https://yoursite.com/bloggenius-ai
 * Description:       Generate complete, SEO-optimized blog posts using AI. Includes title generation, structured content, meta tags, image suggestions, and one-click publish.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            BlogGenius AI
 * Author URI:        https://yoursite.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       bloggenius-ai
 */

defined('ABSPATH') || exit;

// Plugin constants — use __DIR__ for reliable Windows-compatible absolute path
define('BGAI_VERSION', '1.0.0');
define('BGAI_FILE', __FILE__);
define('BGAI_DIR', __DIR__ . DIRECTORY_SEPARATOR);
define('BGAI_URL', plugin_dir_url(__FILE__));
define('BGAI_ASSETS_URL', BGAI_URL . 'assets/');

/**
 * Main plugin bootstrap — fires on plugins_loaded.
 */
function bgai_init()
{
    $inc = BGAI_DIR . 'includes' . DIRECTORY_SEPARATOR;

    require_once $inc . 'class-bgai-settings.php';
    require_once $inc . 'class-bgai-api.php';
    require_once $inc . 'class-bgai-generator.php';
    require_once $inc . 'class-bgai-admin.php';
    require_once $inc . 'class-bgai-ajax.php';

    BGAI_Settings::init();
    BGAI_Admin::init();
    BGAI_Ajax::init();
}
add_action('plugins_loaded', 'bgai_init');

/**
 * Activation hook — set default options.
 */
register_activation_hook(__FILE__, function () {
    if (!get_option('bgai_settings')) {
        update_option('bgai_settings', array(
            'api_key' => '',
            'ai_model' => 'llama-3.3-70b-versatile',
            'ai_provider' => 'groq',
            'post_status' => 'draft',
            'post_author' => 1,
            'post_category' => '',
        ));
    }
    flush_rewrite_rules();
});

/**
 * Migration — upgrade deprecated models (Mixtral sunset)
 */
add_action('plugins_loaded', function() {
    $settings = get_option('bgai_settings');
    if ($settings && isset($settings['ai_model']) && $settings['ai_model'] === 'mixtral-8x7b-32768') {
        $settings['ai_model'] = 'llama-3.3-70b-versatile';
        update_option('bgai_settings', $settings);
    }
}, 5); // Priority 5 runs before bgai_init (default 10)

/**
 * Deactivation hook.
 */
register_deactivation_hook(__FILE__, function () {
    flush_rewrite_rules();
});

﻿<?php defined( 'ABSPATH' ) || exit; ?>
<div class="bgai-wrap">
<div class="bgai-header"><div class="bgai-header-inner">
<div class="bgai-logo">
  <div class="bgai-logo-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg></div>
  <div><h1 class="bgai-logo-title">BlogGenius <span>AI</span></h1><p class="bgai-logo-sub">SEO-Optimized Content Generator</p></div>
</div>
<div class="bgai-header-actions">
  <a href="<?php echo esc_url( admin_url( 'admin.php?page=bloggenius-ai-settings' ) ); ?>" class="bgai-btn bgai-btn-ghost">⚙ Settings</a>
</div>
</div></div>

<?php if ( ! $has_api_key ) : ?>
<div class="bgai-notice bgai-notice-warning">
  ⚠ No API key configured. <a href="<?php echo esc_url( admin_url( 'admin.php?page=bloggenius-ai-settings' ) ); ?>">Add your API key in Settings</a> to start generating content.
</div>
<?php endif; ?>

<div class="bgai-main">
  <!-- LEFT PANEL -->
  <div class="bgai-panel bgai-panel-input">
    <div class="bgai-card">
      <div class="bgai-card-header"><h2 class="bgai-card-title">⚡ Generate Blog Post</h2></div>
      <div class="bgai-card-body">
        <form id="bgai-generator-form">
          <div class="bgai-field">
            <label class="bgai-label" for="bgai-keyword">Focus Keyword *</label>
            <input type="text" id="bgai-keyword" name="keyword" class="bgai-input" placeholder="e.g. best SEO practices 2025" required />
            <p class="bgai-hint">The primary keyword your blog post will target.</p>
          </div>
          <div class="bgai-field-row">
            <div class="bgai-field">
              <label class="bgai-label" for="bgai-tone">Writing Tone</label>
              <select id="bgai-tone" name="tone" class="bgai-select">
                <option value="informative">Informative</option>
                <option value="conversational">Conversational</option>
                <option value="professional">Professional</option>
                <option value="persuasive">Persuasive</option>
                <option value="casual">Casual</option>
              </select>
            </div>
            <div class="bgai-field">
              <label class="bgai-label" for="bgai-language">Language</label>
              <select id="bgai-language" name="language" class="bgai-select">
                <option value="English">English</option>
                <option value="Spanish">Spanish</option>
                <option value="French">French</option>
                <option value="German">German</option>
                <option value="Arabic">Arabic</option>
                <option value="Urdu">Urdu</option>
                <option value="Hindi">Hindi</option>
              </select>
            </div>
          </div>
          <div class="bgai-field">
            <label class="bgai-label" for="bgai-word-count">Target Word Count <span class="bgai-badge" id="bgai-word-count-badge">1200</span></label>
            <input type="range" id="bgai-word-count" name="word_count" class="bgai-range" min="500" max="3000" step="100" value="1200" />
            <div class="bgai-range-labels"><span>500</span><span>1750</span><span>3000</span></div>
          </div>
          <div class="bgai-field">
            <label class="bgai-label" for="bgai-category">Post Category</label>
            <select id="bgai-category" name="category" class="bgai-select">
              <option value="">— Select Category —</option>
              <?php foreach ( $categories as $cat ) : ?>
              <option value="<?php echo esc_attr( $cat->term_id ); ?>"><?php echo esc_html( $cat->name ); ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <button type="submit" id="bgai-generate-btn" class="bgai-btn bgai-btn-primary bgai-btn-full" <?php disabled( ! $has_api_key ); ?>>
            <span>⚡ Generate Blog Post</span>
          </button>
        </form>
      </div>
    </div>

    <div class="bgai-card bgai-seo-card" id="bgai-seo-panel" style="display:none;">
      <div class="bgai-card-header"><h2 class="bgai-card-title">📊 SEO Score</h2></div>
      <div class="bgai-card-body">
        <div class="bgai-seo-score-ring">
          <svg viewBox="0 0 120 120" class="bgai-ring-svg"><circle cx="60" cy="60" r="50" class="bgai-ring-bg"/><circle cx="60" cy="60" r="50" class="bgai-ring-fill" id="bgai-ring-fill"/></svg>
          <div class="bgai-score-number" id="bgai-seo-score">0</div>
        </div>
        <ul class="bgai-seo-checks" id="bgai-seo-checks"></ul>
      </div>
    </div>
  </div>

  <!-- RIGHT PANEL -->
  <div class="bgai-panel bgai-panel-output">
    <div class="bgai-loader" id="bgai-loader" style="display:none;">
      <div class="bgai-loader-inner">
        <div class="bgai-spinner-ring"></div>
        <p class="bgai-loader-text">Generating your content...</p>
        <div class="bgai-loader-steps">
          <div class="bgai-step" id="bgai-step-1">Analyzing keyword</div>
          <div class="bgai-step" id="bgai-step-2">Writing content</div>
          <div class="bgai-step" id="bgai-step-3">Optimizing for SEO</div>
          <div class="bgai-step" id="bgai-step-4">Finalizing post</div>
        </div>
      </div>
    </div>

    <div class="bgai-empty" id="bgai-empty">
      <div class="bgai-empty-inner">
        <div class="bgai-empty-icon">📝</div>
        <h3>Ready to Generate</h3>
        <p>Enter a keyword on the left and click Generate to create a full SEO-optimized blog post with AI.</p>
      </div>
    </div>

    <div id="bgai-output" style="display:none;">
      <!-- Title -->
      <div class="bgai-card">
        <div class="bgai-card-header">
          <h2 class="bgai-card-title">✏ Blog Title</h2>
          <button class="bgai-btn bgai-btn-ghost bgai-btn-sm bgai-copy-btn" data-target="bgai-title-input">Copy</button>
        </div>
        <div class="bgai-card-body">
          <input type="text" id="bgai-title-input" class="bgai-input bgai-title-input" placeholder="Post title..." />
          <div class="bgai-meta-row">
            <span class="bgai-meta-item">Slug: <code id="bgai-slug-display"></code></span>
            <span class="bgai-meta-item" id="bgai-read-time"></span>
          </div>
        </div>
      </div>

      <!-- SEO Meta -->
      <div class="bgai-card">
        <div class="bgai-card-header">
          <h2 class="bgai-card-title">🔍 SEO Meta</h2>
          <button class="bgai-btn bgai-btn-ghost bgai-btn-sm" id="bgai-regen-meta-btn">↺ Regenerate</button>
        </div>
        <div class="bgai-card-body">
          <div class="bgai-serp-preview">
            <div class="bgai-serp-url">https://yoursite.com/<span id="bgai-serp-slug"></span></div>
            <div class="bgai-serp-title" id="bgai-serp-title-preview"></div>
            <div class="bgai-serp-desc" id="bgai-serp-desc-preview"></div>
          </div>
          <div class="bgai-field">
            <label class="bgai-label" for="bgai-meta-title">Meta Title <span class="bgai-char-count"><span id="bgai-meta-title-count">0</span>/60</span></label>
            <input type="text" id="bgai-meta-title" class="bgai-input" maxlength="70" placeholder="SEO meta title..." />
          </div>
          <div class="bgai-field">
            <label class="bgai-label" for="bgai-meta-desc">Meta Description <span class="bgai-char-count"><span id="bgai-meta-desc-count">0</span>/160</span></label>
            <textarea id="bgai-meta-desc" class="bgai-textarea" rows="3" maxlength="170" placeholder="SEO meta description..."></textarea>
          </div>
          <div class="bgai-field">
            <label class="bgai-label" for="bgai-focus-kw">Focus Keyword</label>
            <input type="text" id="bgai-focus-kw" class="bgai-input" placeholder="Primary keyword..." />
          </div>
        </div>
      </div>

      <!-- Image Suggestions -->
      <div class="bgai-card">
        <div class="bgai-card-header"><h2 class="bgai-card-title">🖼 Image Suggestions</h2></div>
        <div class="bgai-card-body"><div class="bgai-image-grid" id="bgai-image-grid"><div class="bgai-image-placeholder"><p>Image suggestions will appear here after generation.</p></div></div></div>
      </div>

      <!-- Content -->
      <div class="bgai-card">
        <div class="bgai-card-header">
          <h2 class="bgai-card-title">📄 Blog Content</h2>
          <div class="bgai-btn-group">
            <button class="bgai-btn bgai-btn-ghost bgai-btn-sm bgai-copy-btn" data-target="bgai-content">Copy</button>
          </div>
        </div>
        <div class="bgai-card-body">
          <div class="bgai-content-tabs">
            <button class="bgai-tab active" data-tab="html">HTML</button>
            <button class="bgai-tab" data-tab="preview">Preview</button>
          </div>
          <div class="bgai-tab-pane active" id="bgai-tab-html">
            <textarea id="bgai-content" class="bgai-textarea bgai-content-area" rows="20" placeholder="Generated HTML content..."></textarea>
          </div>
          <div class="bgai-tab-pane" id="bgai-tab-preview">
            <div class="bgai-preview-area" id="bgai-preview-content"></div>
          </div>
        </div>
      </div>

      <!-- Tags -->
      <div class="bgai-card">
        <div class="bgai-card-header"><h2 class="bgai-card-title">🏷 Tags</h2></div>
        <div class="bgai-card-body">
          <div class="bgai-tags-container" id="bgai-tags-container"></div>
          <p class="bgai-hint">Click a tag to remove it.</p>
        </div>
      </div>

      <!-- Excerpt -->
      <div class="bgai-card">
        <div class="bgai-card-header"><h2 class="bgai-card-title">📋 Post Excerpt</h2></div>
        <div class="bgai-card-body"><textarea id="bgai-excerpt" class="bgai-textarea" rows="3" placeholder="Short post excerpt..."></textarea></div>
      </div>

      <!-- Publish -->
      <div class="bgai-card bgai-publish-card">
        <div class="bgai-card-body">
          <div class="bgai-publish-actions">
            <div class="bgai-publish-status">
              <label class="bgai-label" for="bgai-post-status">Publish Status</label>
              <select id="bgai-post-status" class="bgai-select bgai-select-sm">
                <option value="draft">Save as Draft</option>
                <option value="publish">Publish Immediately</option>
                <option value="pending">Pending Review</option>
              </select>
            </div>
            <div class="bgai-publish-btns">
              <button class="bgai-btn bgai-btn-outline" id="bgai-save-draft-btn">💾 Save Draft</button>
              <button class="bgai-btn bgai-btn-primary" id="bgai-publish-btn">🚀 Publish to WordPress</button>
            </div>
          </div>
        </div>
      </div>
    </div><!-- #bgai-output -->
  </div><!-- .bgai-panel-output -->
</div><!-- .bgai-main -->

<div class="bgai-toast" id="bgai-toast"><span id="bgai-toast-msg"></span><a href="#" id="bgai-toast-link" class="bgai-toast-link" target="_blank" style="display:none;">View Post →</a></div>
<div class="bgai-toast bgai-toast-error" id="bgai-toast-error"><span id="bgai-toast-error-msg"></span></div>
</div><!-- .bgai-wrap -->

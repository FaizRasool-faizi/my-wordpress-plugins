﻿<?php defined( 'ABSPATH' ) || exit; ?>
<div class="bgai-wrap">
<div class="bgai-header"><div class="bgai-header-inner">
  <div class="bgai-logo">
    <div class="bgai-logo-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg></div>
    <div><h1 class="bgai-logo-title">BlogGenius <span>AI</span></h1><p class="bgai-logo-sub">Settings</p></div>
  </div>
  <a href="<?php echo esc_url( admin_url( 'admin.php?page=bloggenius-ai' ) ); ?>" class="bgai-btn bgai-btn-ghost">⚡ Generator</a>
</div></div>

<?php if ( isset( $_GET['settings-updated'] ) ) : ?>
<div class="bgai-notice bgai-notice-success">✓ Settings saved successfully!</div>
<?php endif; ?>

<div class="bgai-settings-layout">
<form method="post" action="options.php" class="bgai-settings-form">
  <?php settings_fields( 'bgai_settings_group' ); ?>

  <div class="bgai-card">
    <div class="bgai-card-header"><h2 class="bgai-card-title">⚡ AI Provider</h2></div>
    <div class="bgai-card-body">
      <div class="bgai-provider-cards">
        <label class="bgai-provider-card <?php echo $settings['ai_provider'] === 'groq' ? 'active' : ''; ?>">
          <input type="radio" name="bgai_settings[ai_provider]" value="groq" <?php checked( $settings['ai_provider'], 'groq' ); ?> class="bgai-provider-radio" />
          <div class="bgai-provider-card-inner">
            <div class="bgai-provider-icon bgai-provider-groq">∞</div>
            <div class="bgai-provider-info"><strong>Groq (FREE)</strong><small>Ultra-Fast, Mixtral, Llama 3</small></div>
            <span class="bgai-provider-check">✓</span>
          </div>
        </label>
        <label class="bgai-provider-card <?php echo $settings['ai_provider'] === 'gemini' ? 'active' : ''; ?>">
          <input type="radio" name="bgai_settings[ai_provider]" value="gemini" <?php checked( $settings['ai_provider'], 'gemini' ); ?> class="bgai-provider-radio" />
          <div class="bgai-provider-card-inner">
            <div class="bgai-provider-icon bgai-provider-gemini">GEM</div>
            <div class="bgai-provider-info"><strong>Google Gemini</strong><small>Gemini 1.5 Flash, Pro</small></div>
            <span class="bgai-provider-check">✓</span>
          </div>
        </label>
      </div>

      <div class="bgai-field">
        <label class="bgai-label" for="bgai-api-key">API Key *</label>
        <div class="bgai-api-key-group">
          <input type="password" id="bgai-api-key" name="bgai_settings[api_key]" class="bgai-input"
                 value="<?php echo esc_attr( $settings['api_key'] ); ?>" placeholder="Paste your API key here..." autocomplete="new-password" />
          <button type="button" class="bgai-btn bgai-btn-ghost bgai-btn-sm" id="bgai-toggle-key">Show</button>
        </div>
        <div class="bgai-api-test-group" style="margin-top: 10px; display: flex; gap: 8px;">
          <button type="button" class="bgai-btn bgai-btn-success bgai-btn-sm" id="bgai-test-connection">🧪 Test Connection</button>
          <span id="bgai-test-result" style="display: none; font-size: 13px; padding: 8px 12px; border-radius: 6px; align-self: center; font-weight: 500;"></span>
        </div>
        <p class="bgai-hint" id="bgai-api-hint-groq">Get your FREE Groq key at <a href="https://console.groq.com/keys" target="_blank" rel="noopener">console.groq.com/keys</a> - No payment required!</p>
        <p class="bgai-hint" id="bgai-api-hint-gemini" style="display:none;">Get your Gemini key at <a href="https://aistudio.google.com/app/apikey" target="_blank">aistudio.google.com/app/apikey</a></p>
      </div>

      <div class="bgai-field">
        <label class="bgai-label" for="bgai-model">AI Model</label>
        <select id="bgai-model" name="bgai_settings[ai_model]" class="bgai-select">
          <optgroup label="Groq (FREE)">
            <option value="llama-3.3-70b-versatile"<?php selected( $settings['ai_model'], 'llama-3.3-70b-versatile' ); ?>>Llama 3.3 70B (Recommended)</option>
            <option value="llama-3.1-70b-versatile"<?php selected( $settings['ai_model'], 'llama-3.1-70b-versatile' ); ?>>Llama 3.1 70B (Fast)</option>
          </optgroup>
          <optgroup label="Google Gemini">
            <option value="gemini-1.5-pro"  <?php selected( $settings['ai_model'], 'gemini-1.5-pro' ); ?>>Gemini 1.5 Pro (Best)</option>
            <option value="gemini-1.5-flash"<?php selected( $settings['ai_model'], 'gemini-1.5-flash' ); ?>>Gemini 1.5 Flash (Fast)</option>
          </optgroup>
        </select>
      </div>
    </div>
  </div>

  <div class="bgai-card">
    <div class="bgai-card-header"><h2 class="bgai-card-title">📝 Publishing Defaults</h2></div>
    <div class="bgai-card-body">
      <div class="bgai-field-row">
        <div class="bgai-field">
          <label class="bgai-label" for="bgai-post-status-default">Default Post Status</label>
          <select id="bgai-post-status-default" name="bgai_settings[post_status]" class="bgai-select">
            <option value="draft"   <?php selected( $settings['post_status'], 'draft' ); ?>>Draft</option>
            <option value="publish" <?php selected( $settings['post_status'], 'publish' ); ?>>Published</option>
            <option value="pending" <?php selected( $settings['post_status'], 'pending' ); ?>>Pending Review</option>
          </select>
        </div>
        <div class="bgai-field">
          <label class="bgai-label" for="bgai-post-author-default">Default Author</label>
          <select id="bgai-post-author-default" name="bgai_settings[post_author]" class="bgai-select">
            <?php foreach ( $authors as $user ) : ?>
            <option value="<?php echo esc_attr( $user->ID ); ?>" <?php selected( $settings['post_author'], $user->ID ); ?>><?php echo esc_html( $user->display_name ); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div class="bgai-field">
        <label class="bgai-label" for="bgai-post-category-default">Default Category</label>
        <select id="bgai-post-category-default" name="bgai_settings[post_category]" class="bgai-select">
          <option value="">— Uncategorized —</option>
          <?php foreach ( $categories as $cat ) : ?>
          <option value="<?php echo esc_attr( $cat->term_id ); ?>" <?php selected( $settings['post_category'], $cat->term_id ); ?>><?php echo esc_html( $cat->name ); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>
  </div>

  <div class="bgai-settings-footer">
    <?php submit_button( 'Save Settings', 'primary', 'submit', false, [ 'class' => 'bgai-btn bgai-btn-primary bgai-btn-lg' ] ); ?>
  </div>
</form>

<aside class="bgai-settings-sidebar">
  <div class="bgai-card">
    <div class="bgai-card-header"><h2 class="bgai-card-title">Quick Help</h2></div>
    <div class="bgai-card-body">
      <div class="bgai-help-item"><div class="bgai-help-icon">1</div><div>Choose your AI provider (Groq FREE or Gemini)</div></div>
      <div class="bgai-help-item"><div class="bgai-help-icon">2</div><div>Paste your API key from the provider dashboard</div></div>
      <div class="bgai-help-item"><div class="bgai-help-icon">3</div><div>Select a model (Llama 3.3 70B recommended for best quality)</div></div>
      <div class="bgai-help-item"><div class="bgai-help-icon">4</div><div>Save and start generating posts!</div></div>
    </div>
  </div>
  <div class="bgai-card">
    <div class="bgai-card-header"><h2 class="bgai-card-title">SEO Plugin Support</h2></div>
    <div class="bgai-card-body">
      <div class="bgai-compat-item"><span class="bgai-compat-dot <?php echo defined('WPSEO_VERSION') ? 'active' : ''; ?>"></span> Yoast SEO <?php echo defined('WPSEO_VERSION') ? '✓ Active' : '(not installed)'; ?></div>
      <div class="bgai-compat-item"><span class="bgai-compat-dot <?php echo class_exists('RankMath') ? 'active' : ''; ?>"></span> Rank Math <?php echo class_exists('RankMath') ? '✓ Active' : '(not installed)'; ?></div>
    </div>
  </div>
  <div class="bgai-card bgai-version-card">
    <div class="bgai-card-body bgai-version-body">
      <div class="bgai-version-badge">v<?php echo esc_html( BGAI_VERSION ); ?></div>
      <p>BlogGenius AI</p>
    </div>
  </div>
</aside>
</div><!-- .bgai-settings-layout -->
</div><!-- .bgai-wrap -->

<script>
jQuery(function($){
    $('#bgai-toggle-key').on('click', function(){
        var i = $('#bgai-api-key');
        i.attr('type', i.attr('type') === 'password' ? 'text' : 'password');
        $(this).text(i.attr('type') === 'password' ? 'Show' : 'Hide');
    });
    $('.bgai-provider-radio').on('change', function(){
        $('.bgai-provider-card').removeClass('active');
        $(this).closest('.bgai-provider-card').addClass('active');
        var p = $(this).val();
        $('#bgai-api-hint-groq').toggle(p === 'groq');
        $('#bgai-api-hint-gemini').toggle(p === 'gemini');
    });


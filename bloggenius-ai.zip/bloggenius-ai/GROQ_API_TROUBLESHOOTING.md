# Groq API Troubleshooting Guide

## Error Handling Enhancements (Updated)

This plugin now includes **robust error handling** for local XAMPP environments with detailed error messages.

---

## Common Errors and Solutions

### 1. **❌ SSL Certificate Verification Failed**
```
Error: SSL verification failed (normal for local XAMPP)
```

**What it means:** Your local XAMPP environment doesn't have proper SSL certificates.

**Solution:** ✅ Already handled automatically - SSL verification is disabled for local development

**What we did:**
- Added `'sslverify' => false` to all API requests
- This is safe for local development but should be enabled in production

---

### 2. **❌ Connection Refused / Cannot Reach API**
```
Error: Connection refused - Check if you are connected to the internet
```

**What it means:** Your computer cannot reach api.groq.com or generativelanguage.googleapis.com

**Solutions:**
- ✅ Check your internet connection is active
- ✅ Check if your firewall or VPN is blocking the connection
- ✅ Temporarily disable VPN/proxy and try again
- ✅ Check if your ISP blocks API calls (try using mobile hotspot)

---

### 3. **❌ DNS Resolution Failed**
```
Error: DNS resolution failed - cannot reach api.groq.com
```

**What it means:** Your DNS cannot resolve (find) the API server's address

**Solutions:**
- ✅ Try restarting your router
- ✅ Try changing DNS in Windows (cmd):
```powershell
ipconfig /flushdns
```
- ✅ Try using Google DNS: `8.8.8.8` and `8.8.4.4`
- ✅ If on a corporate network, ask your IT about API access

---

### 4. **❌ Invalid API Key**
```
Error: Unauthorized - Invalid API key or unauthorized
Error: Authentication Failed
```

**What it means:** Your Groq API key is incorrect, expired, or doesn't have proper permissions

**Solutions:**
- ✅ Get a fresh API key from [console.groq.com/keys](https://console.groq.com/keys)
- ✅ Make sure you copied the entire key (no spaces at start/end)
- ✅ Verify key starts with `gsk_` prefix
- ✅ Ensure your account tier has API access enabled
- ✅ Use the **Test Connection** button to validate instantly

---

### 5. **❌ Rate Limit Exceeded**
```
Error: Rate limit exceeded - try again later
```

**What it means:** You've made too many requests in too short a time

**Solutions:**
- ✅ Wait a few minutes before trying again
- ✅ Spacing out requests (don't generate 10 posts in 10 seconds)
- ✅ Upgrade your Groq account for higher limits

---

### 6. **❌ Request Timed Out**
```
Error: Request timed out - Groq API took too long to respond
Error: cURL timeout
```

**What it means:** The API request took longer than 45 seconds (for test) or 90 seconds (for generation)

**Solutions:**
- ✅ Check your internet connection speed
- ✅ Try again - temporary server delay might be the issue
- ✅ Try a simpler request (fewer words)
- ✅ Check Groq status at [status.groq.com](https://status.groq.com)

---

### 7. **❌ Network Error / Timeout in Test Button**
```
Error: Network error or timeout. Please check your internet connection.
```

**What it means:** The test connection cannot reach Groq

**Solutions:**
1. **First, check api.groq.com is reachable:**
   - Open command prompt (Windows):
   ```powershell
   ping api.groq.com
   ```
   - If it responds with IP address → Internet is fine
   - If "Host not found" → DNS issue

2. **Check your firewall:**
   - Windows Defender might block external API calls
   - Go to Settings → Firewall → Allow app through firewall
   - Look for Apache/XAMPP and enable it

3. **Check port 443 (HTTPS):**
   ```powershell
   Test-NetConnection api.groq.com -Port 443
   ```
   - Should show `TcpTestSucceeded : True`

4. **Try Gemini API instead:**
   - Go to Settings → Switch to "Google Gemini"
   - Get free key from [aistudio.google.com/app/apikey](https://aistudio.google.com/app/apikey)
   - Test - to confirm it's not your API key

---

## WordPress Configuration Checks

### Enable WordPress Debug Logging

Add to `wp-config.php`:

```php
define( 'WP_DEBUG', true );
define( 'WP_DEBUG_LOG', true );
define( 'WP_DEBUG_DISPLAY', false );
```

Check logs in: `/wp-content/debug.log`

### Check PHP Settings

Verify in your XAMPP `php.ini`:

```ini
; Should be >= 60
max_execution_time = 120

; Should be >= 8M
memory_limit = 256M

; Should be enabled
allow_url_fopen = On

; cURL should be enabled
extension=curl
```

Restart XAMPP after changes.

---

## How Our Error Handling Works

### Improved `wp_remote_post()` Configuration

```php
$args = [
    'timeout'     => 45,        // 45 sec for test, 90 sec for generate
    'redirection' => 5,         // Follow up to 5 redirects
    'httpversion' => '1.1',     // Use HTTP/1.1
    'user-agent'  => 'BlogGenius-AI/1.0',
    'blocking'    => true,      // Wait for response
    'headers'     => [...],
    'body'        => $body,
    'sslverify'   => false,     // Disabled for local XAMPP
];
```

### Error Detection

We catch and report:
- ✅ Network connection errors (SSL, DNS, connection refused)
- ✅ cURL specific errors
- ✅ Timeout errors
- ✅ HTTP status errors (401, 429, 500, etc.)
- ✅ JSON parsing errors
- ✅ Invalid API response format

### Error Messages Include

- Error type (what went wrong)
- Possible cause (why it happened)
- Suggested fix (how to fix it)

---

## Quick Test Checklist

Use this to diagnose your setup:

```
[ ] 1. API key obtained from Groq
[ ] 2. API key pasted in BlogGenius settings
[ ] 3. Groq provider selected
[ ] 4. Click "Test Connection" button
[ ] 5. See "✅ Connection Successful!" message
[ ] 6. Generate a test post
[ ] 7. Check email/logs for any errors
```

---

## Groq API Models Available

### Recommended (Free)
- **llama-3.3-70b-versatile** ← Currently selected
- **mixtral-8x7b-32768**
- **llama-3.1-70b-versatile**

### Why Llama 3.3?
- ✅ Latest & most powerful
- ✅ Better content generation
- ✅ Competitive with GPT-3.5
- ✅ 100% FREE

---

## Still Having Issues?

### Check These Files

1. **Error Log:** 
   - Path: `/wp-content/debug.log`
   - Should show exact PHP error

2. **XAMPP Error Log:**
   - Path: `C:\xampp\apache\logs\error.log`
   - Shows server issues

3. **Browser Console:**
   - Press `F12` → Console tab
   - Look for AJAX error messages

### Get Help

- Visit: [console.groq.com/docs](https://console.groq.com/docs)
- Check Groq status: [status.groq.com](https://status.groq.com)
- Test API directly: Use cURL from command line:

```bash
curl -X POST https://api.groq.com/openai/v1/chat/completions \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"llama-3.3-70b-versatile","messages":[{"role":"user","content":"hi"}],"max_tokens":50}'
```

---

## Version Info

- **Plugin Version:** 1.0.0
- **Last Updated:** March 5, 2026
- **Default Provider:** Groq (FREE)
- **Default Model:** Llama 3.3 70B
- **SSL Verify:** Disabled (local dev)
- **Timeout:** 45s (test), 90s (generate)
